import pkg from 'pg';
const { Client } = pkg;
import * as schema from '../shared/schema';

async function main() {
  console.log('Setting up database...');
  
  try {
    // Connect to the database using Client for raw SQL commands
    const client = new Client({
      connectionString: process.env.DATABASE_URL!,
    });
    await client.connect();
    
    // Create tables
    console.log('Creating database tables...');
    await client.query(`
      -- Users table
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        first_name TEXT,
        last_name TEXT,
        avatar_url TEXT,
        preferences JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      
      -- Avatars table
      CREATE TABLE IF NOT EXISTS avatars (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        body_type TEXT,
        height INTEGER,
        skin_tone TEXT,
        hair_color TEXT,
        eye_color TEXT,
        customizations JSONB
      );
      
      -- Fashion items table
      CREATE TABLE IF NOT EXISTS fashion_items (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        type TEXT NOT NULL,
        brand TEXT,
        color TEXT NOT NULL,
        size TEXT,
        season TEXT,
        event_type TEXT,
        rental_price INTEGER,
        rental_duration INTEGER,
        image_url TEXT,
        is_available BOOLEAN DEFAULT TRUE
      );
      
      -- Rentals table
      CREATE TABLE IF NOT EXISTS rentals (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        item_id INTEGER NOT NULL REFERENCES fashion_items(id),
        start_date TIMESTAMP WITH TIME ZONE NOT NULL,
        end_date TIMESTAMP WITH TIME ZONE NOT NULL,
        status TEXT NOT NULL,
        total_price INTEGER NOT NULL
      );
      
      -- Events table
      CREATE TABLE IF NOT EXISTS events (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        title TEXT NOT NULL,
        description TEXT,
        date TIMESTAMP WITH TIME ZONE NOT NULL,
        location TEXT,
        event_type TEXT NOT NULL,
        calendar_source TEXT,
        outfit_id INTEGER
      );
      
      -- Outfits table
      CREATE TABLE IF NOT EXISTS outfits (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        name TEXT NOT NULL,
        items JSONB NOT NULL,
        event_type TEXT,
        season TEXT,
        is_recommended BOOLEAN DEFAULT FALSE,
        rating INTEGER
      );
    `);
    
    // Create some sample data to demonstrate the app
    console.log('Creating sample fashion items...');
    
    const categories = ['Tops', 'Bottoms', 'Dresses', 'Outerwear', 'Shoes', 'Accessories'];
    const eventTypes = ['Formal', 'Casual', 'Business', 'Party', 'Wedding', 'Outdoor'];
    const seasons = ['Spring', 'Summer', 'Fall', 'Winter'];
    const colors = ['Black', 'White', 'Blue', 'Red', 'Green', 'Yellow', 'Pink', 'Purple', 'Brown', 'Grey'];
    const brands = ['Versace', 'Tom Ford', 'Louis Vuitton', 'Cartier', 'Gucci', 'Prada', 'Dior', 'Chanel'];
    const images = [
      "https://images.unsplash.com/photo-1525450824786-227cbef70703?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=436&q=80",
      "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
      "https://images.unsplash.com/photo-1618886614638-80e3c103d31a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=370&q=80"
    ];
    
    // Insert sample fashion items
    for (let i = 0; i < 20; i++) {
      const category = categories[Math.floor(Math.random() * categories.length)];
      const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
      const season = seasons[Math.floor(Math.random() * seasons.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const brand = brands[Math.floor(Math.random() * brands.length)];
      const price = Math.floor(Math.random() * 20000) + 5000; // 50-250 USD
      const duration = [1, 3, 7, 14][Math.floor(Math.random() * 4)];
      const image = images[Math.floor(Math.random() * images.length)];
      const size = ['XS', 'S', 'M', 'L', 'XL'][Math.floor(Math.random() * 5)];
      
      await client.query(
        `INSERT INTO fashion_items (
          name, description, category, type, brand, color, size, 
          season, event_type, rental_price, rental_duration, image_url, is_available
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          `${brand} ${category} Item`,
          `Beautiful ${color} ${category.toLowerCase()} item by ${brand}`,
          category,
          category,
          brand,
          color,
          size,
          season,
          eventType,
          price,
          duration,
          image,
          true
        ]
      );
    }
    
    console.log('Database setup complete!');
  } catch (error) {
    console.error('Error setting up database:', error);
    process.exit(1);
  }
  
  process.exit(0);
}

main();