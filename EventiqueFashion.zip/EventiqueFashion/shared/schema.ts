import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  avatarUrl: text("avatar_url"),
  preferences: jsonb("preferences"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Avatar model
export const avatars = pgTable("avatars", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  bodyType: text("body_type"),
  height: integer("height"),
  skinTone: text("skin_tone"),
  hairColor: text("hair_color"),
  eyeColor: text("eye_color"),
  customizations: jsonb("customizations"),
});

export const insertAvatarSchema = createInsertSchema(avatars).omit({
  id: true,
});

// Fashion items
export const fashionItems = pgTable("fashion_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // Tops, Bottoms, Shoes, etc.
  type: text("type").notNull(), // Blouse, Skirt, Sneakers, etc.
  brand: text("brand"),
  color: text("color").notNull(),
  size: text("size"),
  season: text("season"), // Spring, Summer, Fall, Winter
  eventType: text("event_type"), // Formal, Casual, Business, etc.
  rentalPrice: integer("rental_price"), // Price in cents
  rentalDuration: integer("rental_duration"), // Duration in days
  imageUrl: text("image_url"),
  isAvailable: boolean("is_available").default(true),
});

export const insertFashionItemSchema = createInsertSchema(fashionItems).omit({
  id: true,
});

// Rentals
export const rentals = pgTable("rentals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  itemId: integer("item_id").notNull().references(() => fashionItems.id),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull(), // Pending, Active, Returned, Cancelled
  totalPrice: integer("total_price").notNull(), // Price in cents
});

export const insertRentalSchema = createInsertSchema(rentals).omit({
  id: true,
});

// Events
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  date: timestamp("date").notNull(),
  location: text("location"),
  eventType: text("event_type").notNull(), // Formal, Casual, Business, etc.
  calendarSource: text("calendar_source"), // Google, Apple, Outlook
  outfitId: integer("outfit_id"), // Optional reference to a saved outfit
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
});

// Outfits (combinations of fashion items)
export const outfits = pgTable("outfits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  items: jsonb("items").notNull(), // Array of fashion item IDs
  eventType: text("event_type"), // Formal, Casual, Business, etc.
  season: text("season"), // Spring, Summer, Fall, Winter
  isRecommended: boolean("is_recommended").default(false),
  rating: integer("rating"), // User rating of the outfit
});

export const insertOutfitSchema = createInsertSchema(outfits).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Avatar = typeof avatars.$inferSelect;
export type InsertAvatar = z.infer<typeof insertAvatarSchema>;

export type FashionItem = typeof fashionItems.$inferSelect;
export type InsertFashionItem = z.infer<typeof insertFashionItemSchema>;

export type Rental = typeof rentals.$inferSelect;
export type InsertRental = z.infer<typeof insertRentalSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Outfit = typeof outfits.$inferSelect;
export type InsertOutfit = z.infer<typeof insertOutfitSchema>;
