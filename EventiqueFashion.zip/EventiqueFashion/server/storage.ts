import { 
  users, type User, type InsertUser,
  avatars, type Avatar, type InsertAvatar,
  fashionItems, type FashionItem, type InsertFashionItem,
  rentals, type Rental, type InsertRental,
  events, type Event, type InsertEvent,
  outfits, type Outfit, type InsertOutfit
} from "@shared/schema";
import { eq } from "drizzle-orm";
import { db } from './db';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Avatar operations
  getAvatar(id: number): Promise<Avatar | undefined>;
  getAvatarByUserId(userId: number): Promise<Avatar | undefined>;
  createAvatar(avatar: InsertAvatar): Promise<Avatar>;
  updateAvatar(id: number, data: Partial<InsertAvatar>): Promise<Avatar | undefined>;
  
  // Fashion item operations
  getFashionItem(id: number): Promise<FashionItem | undefined>;
  getFashionItems(limit?: number, offset?: number): Promise<FashionItem[]>;
  getFashionItemsByCategory(category: string): Promise<FashionItem[]>;
  getFashionItemsByEventType(eventType: string): Promise<FashionItem[]>;
  getFashionItemsBySeason(season: string): Promise<FashionItem[]>;
  createFashionItem(item: InsertFashionItem): Promise<FashionItem>;
  
  // Rental operations
  getRental(id: number): Promise<Rental | undefined>;
  getRentalsByUserId(userId: number): Promise<Rental[]>;
  createRental(rental: InsertRental): Promise<Rental>;
  updateRentalStatus(id: number, status: string): Promise<Rental | undefined>;
  
  // Event operations
  getEvent(id: number): Promise<Event | undefined>;
  getEventsByUserId(userId: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Outfit operations
  getOutfit(id: number): Promise<Outfit | undefined>;
  getOutfitsByUserId(userId: number): Promise<Outfit[]>;
  createOutfit(outfit: InsertOutfit): Promise<Outfit>;
  updateOutfitRating(id: number, rating: number): Promise<Outfit | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private avatars: Map<number, Avatar>;
  private fashionItems: Map<number, FashionItem>;
  private rentals: Map<number, Rental>;
  private events: Map<number, Event>;
  private outfits: Map<number, Outfit>;
  
  private userIdCounter: number;
  private avatarIdCounter: number;
  private fashionItemIdCounter: number;
  private rentalIdCounter: number;
  private eventIdCounter: number;
  private outfitIdCounter: number;

  constructor() {
    this.users = new Map();
    this.avatars = new Map();
    this.fashionItems = new Map();
    this.rentals = new Map();
    this.events = new Map();
    this.outfits = new Map();
    
    this.userIdCounter = 1;
    this.avatarIdCounter = 1;
    this.fashionItemIdCounter = 1;
    this.rentalIdCounter = 1;
    this.eventIdCounter = 1;
    this.outfitIdCounter = 1;
    
    this.initializeData();
  }
  
  private initializeData() {
    // Add some initial fashion items for displaying on the frontend
    const categories = ['Tops', 'Bottoms', 'Dresses', 'Outerwear', 'Shoes', 'Accessories'];
    const eventTypes = ['Formal', 'Casual', 'Business', 'Party', 'Wedding', 'Outdoor'];
    const seasons = ['Spring', 'Summer', 'Fall', 'Winter'];
    const colors = ['Black', 'White', 'Blue', 'Red', 'Green', 'Yellow', 'Pink', 'Purple', 'Brown', 'Grey'];
    const brands = ['Versace', 'Tom Ford', 'Louis Vuitton', 'Cartier', 'Gucci', 'Prada', 'Dior', 'Chanel'];
    const images = [
      "https://images.unsplash.com/photo-1525450824786-227cbef70703?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=436&q=80",
      "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
      "https://images.unsplash.com/photo-1618886614638-80e3c103d31a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=370&q=80"
    ];
    
    for (let i = 0; i < 20; i++) {
      const category = categories[Math.floor(Math.random() * categories.length)];
      const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
      const season = seasons[Math.floor(Math.random() * seasons.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const brand = brands[Math.floor(Math.random() * brands.length)];
      const price = Math.floor(Math.random() * 20000) + 5000; // 50-250 USD
      const duration = [1, 3, 7, 14][Math.floor(Math.random() * 4)];
      const image = images[Math.floor(Math.random() * images.length)];
      
      this.createFashionItem({
        name: `${brand} ${category} Item`,
        description: `Beautiful ${color} ${category.toLowerCase()} item by ${brand}`,
        category,
        type: category,
        brand,
        color,
        size: ['XS', 'S', 'M', 'L', 'XL'][Math.floor(Math.random() * 5)],
        season,
        eventType,
        rentalPrice: price,
        rentalDuration: duration,
        imageUrl: image,
        isAvailable: true
      });
    }
  }

  // User implementations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { ...user, id, createdAt: new Date() };
    this.users.set(id, newUser);
    return newUser;
  }

  // Avatar implementations
  async getAvatar(id: number): Promise<Avatar | undefined> {
    return this.avatars.get(id);
  }

  async getAvatarByUserId(userId: number): Promise<Avatar | undefined> {
    return Array.from(this.avatars.values()).find(avatar => avatar.userId === userId);
  }

  async createAvatar(avatar: InsertAvatar): Promise<Avatar> {
    const id = this.avatarIdCounter++;
    const newAvatar: Avatar = { ...avatar, id };
    this.avatars.set(id, newAvatar);
    return newAvatar;
  }

  async updateAvatar(id: number, data: Partial<InsertAvatar>): Promise<Avatar | undefined> {
    const avatar = this.avatars.get(id);
    if (!avatar) return undefined;
    
    const updatedAvatar: Avatar = { ...avatar, ...data };
    this.avatars.set(id, updatedAvatar);
    return updatedAvatar;
  }

  // Fashion item implementations
  async getFashionItem(id: number): Promise<FashionItem | undefined> {
    return this.fashionItems.get(id);
  }

  async getFashionItems(limit = 50, offset = 0): Promise<FashionItem[]> {
    return Array.from(this.fashionItems.values())
      .slice(offset, offset + limit);
  }

  async getFashionItemsByCategory(category: string): Promise<FashionItem[]> {
    return Array.from(this.fashionItems.values())
      .filter(item => item.category === category);
  }

  async getFashionItemsByEventType(eventType: string): Promise<FashionItem[]> {
    return Array.from(this.fashionItems.values())
      .filter(item => item.eventType === eventType);
  }

  async getFashionItemsBySeason(season: string): Promise<FashionItem[]> {
    return Array.from(this.fashionItems.values())
      .filter(item => item.season === season);
  }

  async createFashionItem(item: InsertFashionItem): Promise<FashionItem> {
    const id = this.fashionItemIdCounter++;
    const newItem: FashionItem = { ...item, id };
    this.fashionItems.set(id, newItem);
    return newItem;
  }

  // Rental implementations
  async getRental(id: number): Promise<Rental | undefined> {
    return this.rentals.get(id);
  }

  async getRentalsByUserId(userId: number): Promise<Rental[]> {
    return Array.from(this.rentals.values())
      .filter(rental => rental.userId === userId);
  }

  async createRental(rental: InsertRental): Promise<Rental> {
    const id = this.rentalIdCounter++;
    const newRental: Rental = { ...rental, id };
    this.rentals.set(id, newRental);
    return newRental;
  }

  async updateRentalStatus(id: number, status: string): Promise<Rental | undefined> {
    const rental = this.rentals.get(id);
    if (!rental) return undefined;
    
    const updatedRental: Rental = { ...rental, status };
    this.rentals.set(id, updatedRental);
    return updatedRental;
  }

  // Event implementations
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async getEventsByUserId(userId: number): Promise<Event[]> {
    return Array.from(this.events.values())
      .filter(event => event.userId === userId);
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const newEvent: Event = { ...event, id };
    this.events.set(id, newEvent);
    return newEvent;
  }

  // Outfit implementations
  async getOutfit(id: number): Promise<Outfit | undefined> {
    return this.outfits.get(id);
  }

  async getOutfitsByUserId(userId: number): Promise<Outfit[]> {
    return Array.from(this.outfits.values())
      .filter(outfit => outfit.userId === userId);
  }

  async createOutfit(outfit: InsertOutfit): Promise<Outfit> {
    const id = this.outfitIdCounter++;
    const newOutfit: Outfit = { ...outfit, id };
    this.outfits.set(id, newOutfit);
    return newOutfit;
  }

  async updateOutfitRating(id: number, rating: number): Promise<Outfit | undefined> {
    const outfit = this.outfits.get(id);
    if (!outfit) return undefined;
    
    const updatedOutfit: Outfit = { ...outfit, rating };
    this.outfits.set(id, updatedOutfit);
    return updatedOutfit;
  }
}

export class DatabaseStorage implements IStorage {

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  // Avatar operations
  async getAvatar(id: number): Promise<Avatar | undefined> {
    const result = await db.select().from(avatars).where(eq(avatars.id, id));
    return result[0];
  }

  async getAvatarByUserId(userId: number): Promise<Avatar | undefined> {
    const result = await db.select().from(avatars).where(eq(avatars.userId, userId));
    return result[0];
  }

  async createAvatar(avatar: InsertAvatar): Promise<Avatar> {
    const result = await db.insert(avatars).values(avatar).returning();
    return result[0];
  }

  async updateAvatar(id: number, data: Partial<InsertAvatar>): Promise<Avatar | undefined> {
    const result = await db.update(avatars)
      .set(data)
      .where(eq(avatars.id, id))
      .returning();
    return result[0];
  }

  // Fashion item operations
  async getFashionItem(id: number): Promise<FashionItem | undefined> {
    const result = await db.select().from(fashionItems).where(eq(fashionItems.id, id));
    return result[0];
  }

  async getFashionItems(limit = 50, offset = 0): Promise<FashionItem[]> {
    return await db.select().from(fashionItems).limit(limit).offset(offset);
  }

  async getFashionItemsByCategory(category: string): Promise<FashionItem[]> {
    return await db.select().from(fashionItems).where(eq(fashionItems.category, category));
  }

  async getFashionItemsByEventType(eventType: string): Promise<FashionItem[]> {
    return await db.select().from(fashionItems).where(eq(fashionItems.eventType, eventType));
  }

  async getFashionItemsBySeason(season: string): Promise<FashionItem[]> {
    return await db.select().from(fashionItems).where(eq(fashionItems.season, season));
  }

  async createFashionItem(item: InsertFashionItem): Promise<FashionItem> {
    const result = await db.insert(fashionItems).values(item).returning();
    return result[0];
  }

  // Rental operations
  async getRental(id: number): Promise<Rental | undefined> {
    const result = await db.select().from(rentals).where(eq(rentals.id, id));
    return result[0];
  }

  async getRentalsByUserId(userId: number): Promise<Rental[]> {
    return await db.select().from(rentals).where(eq(rentals.userId, userId));
  }

  async createRental(rental: InsertRental): Promise<Rental> {
    const result = await db.insert(rentals).values(rental).returning();
    return result[0];
  }

  async updateRentalStatus(id: number, status: string): Promise<Rental | undefined> {
    const result = await db.update(rentals)
      .set({ status })
      .where(eq(rentals.id, id))
      .returning();
    return result[0];
  }

  // Event operations
  async getEvent(id: number): Promise<Event | undefined> {
    const result = await db.select().from(events).where(eq(events.id, id));
    return result[0];
  }

  async getEventsByUserId(userId: number): Promise<Event[]> {
    return await db.select().from(events).where(eq(events.userId, userId));
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const result = await db.insert(events).values(event).returning();
    return result[0];
  }

  // Outfit operations
  async getOutfit(id: number): Promise<Outfit | undefined> {
    const result = await db.select().from(outfits).where(eq(outfits.id, id));
    return result[0];
  }

  async getOutfitsByUserId(userId: number): Promise<Outfit[]> {
    return await db.select().from(outfits).where(eq(outfits.userId, userId));
  }

  async createOutfit(outfit: InsertOutfit): Promise<Outfit> {
    const result = await db.insert(outfits).values(outfit).returning();
    return result[0];
  }

  async updateOutfitRating(id: number, rating: number): Promise<Outfit | undefined> {
    const result = await db.update(outfits)
      .set({ rating })
      .where(eq(outfits.id, id))
      .returning();
    return result[0];
  }
}

// Use DatabaseStorage for persistent database storage
export const storage = new DatabaseStorage();
