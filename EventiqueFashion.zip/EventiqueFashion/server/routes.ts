import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertAvatarSchema, 
  insertFashionItemSchema,
  insertRentalSchema,
  insertEventSchema,
  insertOutfitSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handler for Zod validation errors
  const handleZodError = (error: unknown, res: Response) => {
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ 
        message: validationError.message,
        errors: error.errors 
      });
    }
    return res.status(500).json({ message: 'Internal server error' });
  };

  // User routes
  app.post('/api/users/register', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user with same email or username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: 'Username already taken' });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: 'Email already registered' });
      }
      
      const user = await storage.createUser(userData);
      return res.status(201).json({ 
        id: user.id,
        username: user.username,
        email: user.email 
      });
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  app.post('/api/users/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }
      
      return res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email
      });
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Avatar routes
  app.post('/api/avatars', async (req: Request, res: Response) => {
    try {
      const avatarData = insertAvatarSchema.parse(req.body);
      const avatar = await storage.createAvatar(avatarData);
      return res.status(201).json(avatar);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  app.get('/api/avatars/user/:userId', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const avatar = await storage.getAvatarByUserId(userId);
      if (!avatar) {
        return res.status(404).json({ message: 'Avatar not found' });
      }
      
      return res.status(200).json(avatar);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.patch('/api/avatars/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid avatar ID' });
      }
      
      const updatedAvatar = await storage.updateAvatar(id, req.body);
      if (!updatedAvatar) {
        return res.status(404).json({ message: 'Avatar not found' });
      }
      
      return res.status(200).json(updatedAvatar);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Fashion item routes
  app.get('/api/fashion-items', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : undefined;
      
      const items = await storage.getFashionItems(limit, offset);
      return res.status(200).json(items);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/fashion-items/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid item ID' });
      }
      
      const item = await storage.getFashionItem(id);
      if (!item) {
        return res.status(404).json({ message: 'Fashion item not found' });
      }
      
      return res.status(200).json(item);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/fashion-items/category/:category', async (req: Request, res: Response) => {
    try {
      const category = req.params.category;
      const items = await storage.getFashionItemsByCategory(category);
      return res.status(200).json(items);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/fashion-items/event-type/:eventType', async (req: Request, res: Response) => {
    try {
      const eventType = req.params.eventType;
      const items = await storage.getFashionItemsByEventType(eventType);
      return res.status(200).json(items);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/fashion-items/season/:season', async (req: Request, res: Response) => {
    try {
      const season = req.params.season;
      const items = await storage.getFashionItemsBySeason(season);
      return res.status(200).json(items);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post('/api/fashion-items', async (req: Request, res: Response) => {
    try {
      const itemData = insertFashionItemSchema.parse(req.body);
      const item = await storage.createFashionItem(itemData);
      return res.status(201).json(item);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  // Rental routes
  app.post('/api/rentals', async (req: Request, res: Response) => {
    try {
      const rentalData = insertRentalSchema.parse(req.body);
      
      // Check if item exists and is available
      const item = await storage.getFashionItem(rentalData.itemId);
      if (!item) {
        return res.status(404).json({ message: 'Fashion item not found' });
      }
      
      if (!item.isAvailable) {
        return res.status(400).json({ message: 'Item is not available for rental' });
      }
      
      const rental = await storage.createRental(rentalData);
      return res.status(201).json(rental);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  app.get('/api/rentals/user/:userId', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const rentals = await storage.getRentalsByUserId(userId);
      return res.status(200).json(rentals);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.patch('/api/rentals/:id/status', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid rental ID' });
      }
      
      const { status } = req.body;
      if (!status || !['Pending', 'Active', 'Returned', 'Cancelled'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      
      const updatedRental = await storage.updateRentalStatus(id, status);
      if (!updatedRental) {
        return res.status(404).json({ message: 'Rental not found' });
      }
      
      return res.status(200).json(updatedRental);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Event routes
  app.post('/api/events', async (req: Request, res: Response) => {
    try {
      const eventData = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(eventData);
      return res.status(201).json(event);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  app.get('/api/events/user/:userId', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const events = await storage.getEventsByUserId(userId);
      return res.status(200).json(events);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Outfit routes
  app.post('/api/outfits', async (req: Request, res: Response) => {
    try {
      const outfitData = insertOutfitSchema.parse(req.body);
      const outfit = await storage.createOutfit(outfitData);
      return res.status(201).json(outfit);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  app.get('/api/outfits/user/:userId', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const outfits = await storage.getOutfitsByUserId(userId);
      return res.status(200).json(outfits);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.patch('/api/outfits/:id/rating', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid outfit ID' });
      }
      
      const { rating } = req.body;
      if (rating === undefined || isNaN(rating) || rating < 1 || rating > 5) {
        return res.status(400).json({ message: 'Invalid rating. Must be between 1 and 5' });
      }
      
      const updatedOutfit = await storage.updateOutfitRating(id, rating);
      if (!updatedOutfit) {
        return res.status(404).json({ message: 'Outfit not found' });
      }
      
      return res.status(200).json(updatedOutfit);
    } catch (error) {
      return res.status(500).json({ message: 'Internal server error' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
