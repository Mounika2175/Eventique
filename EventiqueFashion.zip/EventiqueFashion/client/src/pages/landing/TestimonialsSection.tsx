import { motion } from "framer-motion";
import { useState } from "react";

const testimonials = [
  {
    quote: "EVENTIQUE has completely transformed my approach to fashion. The AI recommendations are eerily accurate, and the virtual try-on feature has saved me from countless fashion mistakes!",
    author: "Jennifer L.",
    role: "Marketing Executive",
    imageUrl: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80"
  },
  {
    quote: "As someone who attends a lot of events for work, the rental service has been a game-changer. I've saved thousands on outfits I'd only wear once, and the quality is top-notch.",
    author: "Michael T.",
    role: "Event Planner",
    imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
  },
  {
    quote: "I love how EVENTIQUE integrates with my calendar. It automatically suggests outfits for upcoming events, considering weather and dress code. It's like having a personal stylist!",
    author: "Samantha P.",
    role: "Sales Director",
    imageUrl: "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=689&q=80"
  }
];

export default function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-20 bg-[#F8F8F8]">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
            What Our Users Say
          </h2>
          <p className="max-w-3xl mx-auto text-[#4A4A4A]">
            Hear from our community about how EVENTIQUE has transformed their fashion experience and simplified their style decisions.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto relative">
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out" 
              style={{ transform: `translateX(-${activeIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <motion.div 
                  key={index}
                  className="w-full flex-shrink-0 p-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="bg-white rounded-2xl shadow-lg p-8 md:p-10">
                    <div className="flex flex-col md:flex-row items-center">
                      <div className="md:w-1/3 mb-6 md:mb-0">
                        <div className="rounded-xl overflow-hidden w-32 h-32 mx-auto">
                          <img 
                            src={testimonial.imageUrl} 
                            alt={testimonial.author} 
                            className="w-full h-full object-cover" 
                          />
                        </div>
                      </div>
                      <div className="md:w-2/3 md:pl-8">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          className="h-10 w-10 text-[#E8C8A9] mb-4" 
                          fill="currentColor" 
                          viewBox="0 0 24 24"
                        >
                          <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                        </svg>
                        <p className="text-[#4A4A4A] text-lg mb-6 italic">
                          "{testimonial.quote}"
                        </p>
                        <div>
                          <h4 className="font-[Playfair_Display] text-xl font-semibold text-[#222222]">{testimonial.author}</h4>
                          <p className="text-[#888888]">{testimonial.role}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === activeIndex ? 'bg-[#E8C8A9]' : 'bg-[#E1E1E1]'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>

          <button 
            onClick={prevTestimonial}
            className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-6 md:-translate-x-12 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:bg-[#F8F8F8] transition-colors z-10"
            aria-label="Previous testimonial"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-6 w-6 text-[#222222]" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button 
            onClick={nextTestimonial}
            className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-6 md:translate-x-12 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:bg-[#F8F8F8] transition-colors z-10"
            aria-label="Next testimonial"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-6 w-6 text-[#222222]" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        <motion.div 
          className="mt-20 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222] mb-4">
            Featured In
          </h3>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 mt-8">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/The_New_York_Times_logo.svg/2560px-The_New_York_Times_logo.svg.png" 
              alt="New York Times" 
              className="h-8 md:h-10 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all" 
            />
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Vogue_Logo.svg/2560px-Vogue_Logo.svg.png" 
              alt="Vogue" 
              className="h-6 md:h-8 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all" 
            />
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/The_Wall_Street_Journal.svg/2560px-The_Wall_Street_Journal.svg.png" 
              alt="Wall Street Journal" 
              className="h-6 md:h-8 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all" 
            />
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/TechCrunch_logo.svg/2560px-TechCrunch_logo.svg.png" 
              alt="TechCrunch" 
              className="h-8 md:h-10 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all" 
            />
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Forbes_logo.svg/2560px-Forbes_logo.svg.png" 
              alt="Forbes" 
              className="h-6 md:h-8 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all" 
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
