import { Helmet } from "react-helmet";
import AboutSection from "./AboutSection";
import HighlightsSection from "./HighlightsSection";
import TeamSection from "./TeamSection";
import TestimonialsSection from "./TestimonialsSection";
import CTASection from "../home/CTASection";

export default function LandingPage() {
  return (
    <>
      <Helmet>
        <title>About EVENTIQUE - Virtual Fashion Platform</title>
        <meta name="description" content="Learn about EVENTIQUE, our mission, values, and how we're revolutionizing fashion with AI technology." />
      </Helmet>
      <div>
        <AboutSection />
        <HighlightsSection />
        <TeamSection />
        <TestimonialsSection />
        <CTASection />
      </div>
    </>
  );
}
