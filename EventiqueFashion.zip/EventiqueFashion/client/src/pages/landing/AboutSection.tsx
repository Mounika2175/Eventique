import { motion } from "framer-motion";

export default function AboutSection() {
  return (
    <section className="py-20 md:py-28 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[Playfair_Display] text-4xl md:text-5xl lg:text-6xl font-bold text-[#222222] mb-6">
              About EVENTIQUE
            </h1>
            <p className="text-lg md:text-xl text-[#4A4A4A] max-w-3xl mx-auto">
              Redefining fashion with AI-powered personalization, virtual try-ons, and premium rentals for every occasion.
            </p>
          </motion.div>

          <div className="flex flex-col lg:flex-row items-center mb-20">
            <motion.div 
              className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-12"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-6">
                Our Vision
              </h2>
              <p className="text-[#4A4A4A] mb-6">
                EVENTIQUE was founded with a singular vision: to transform how people experience fashion in the digital age. We believe that technology should make fashion more accessible, sustainable, and personalized for everyone.
              </p>
              <p className="text-[#4A4A4A]">
                By combining advanced AI algorithms with fashion expertise, we're building a platform that understands your unique style preferences and helps you look your best for every occasion, without the need to permanently purchase items you'll only wear once.
              </p>
            </motion.div>

            <motion.div 
              className="lg:w-1/2"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1573855619003-97b4799dcd8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" 
                  alt="Fashion Design Studio" 
                  className="w-full h-full object-cover" 
                />
              </div>
            </motion.div>
          </div>

          <div className="flex flex-col lg:flex-row-reverse items-center">
            <motion.div 
              className="lg:w-1/2 mb-10 lg:mb-0 lg:pl-12"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-6">
                Our Mission
              </h2>
              <p className="text-[#4A4A4A] mb-6">
                Our mission is to empower people to express themselves confidently through fashion while promoting sustainability in the industry. We're committed to reducing fashion waste by offering high-quality rentals as an alternative to fast fashion consumption.
              </p>
              <p className="text-[#4A4A4A]">
                Through our AI-powered personalization and virtual try-on technology, we're eliminating uncertainty from fashion choices and helping our users make more informed decisions about what they wear and how they shop.
              </p>
            </motion.div>

            <motion.div 
              className="lg:w-1/2"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1574&q=80" 
                  alt="Sustainable Fashion" 
                  className="w-full h-full object-cover" 
                />
              </div>
            </motion.div>
          </div>

          <motion.div 
            className="mt-20 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-6">
              Our Values
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
              <div className="bg-[#F8F8F8] rounded-xl p-6 text-left transition-all duration-300 hover:shadow-lg">
                <div className="w-12 h-12 rounded-full bg-[#E8C8A9] bg-opacity-30 flex items-center justify-center mb-4">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-6 w-6 text-[#E8C8A9]" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-2">Innovation</h3>
                <p className="text-[#4A4A4A]">
                  We're constantly pushing the boundaries of fashion technology to create experiences that were once thought impossible.
                </p>
              </div>
              
              <div className="bg-[#F8F8F8] rounded-xl p-6 text-left transition-all duration-300 hover:shadow-lg">
                <div className="w-12 h-12 rounded-full bg-[#E8C8A9] bg-opacity-30 flex items-center justify-center mb-4">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-6 w-6 text-[#E8C8A9]" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                  </svg>
                </div>
                <h3 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-2">Sustainability</h3>
                <p className="text-[#4A4A4A]">
                  We believe in responsible fashion consumption and are committed to reducing the environmental impact of the fashion industry.
                </p>
              </div>
              
              <div className="bg-[#F8F8F8] rounded-xl p-6 text-left transition-all duration-300 hover:shadow-lg">
                <div className="w-12 h-12 rounded-full bg-[#E8C8A9] bg-opacity-30 flex items-center justify-center mb-4">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-6 w-6 text-[#E8C8A9]" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-2">Inclusivity</h3>
                <p className="text-[#4A4A4A]">
                  Fashion is for everyone. We're building technology that serves people of all body types, styles, and backgrounds.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
