import { motion } from "framer-motion";

const highlights = [
  {
    title: "AI-Driven Fashion",
    description: "Our proprietary AI algorithm analyzes thousands of fashion combinations to provide personalized recommendations based on your body type, skin tone, and style preferences.",
    imageUrl: "https://images.unsplash.com/photo-1566241440091-ec10de8db2e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    stats: [
      { value: "95%", label: "User Satisfaction" },
      { value: "78%", label: "Style Match Accuracy" },
      { value: "60%", label: "Reduced Decision Time" }
    ]
  },
  {
    title: "Cutting-Edge 3D Technology",
    description: "Create a digital twin with precise measurements for virtual try-ons. Our 3D rendering technology accurately shows how each garment drapes and moves on your body.",
    imageUrl: "https://images.unsplash.com/photo-1617867454321-f648b6427039?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    stats: [
      { value: "99%", label: "Size Accuracy" },
      { value: "1.2M+", label: "Virtual Try-Ons" },
      { value: "85%", label: "Return Rate Reduction" }
    ]
  },
  {
    title: "Premium Fashion Rental Network",
    description: "Access designer pieces for a fraction of the purchase price. Our rental network spans 200+ premium brands, with garments professionally cleaned and maintained.",
    imageUrl: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    stats: [
      { value: "200+", label: "Designer Brands" },
      { value: "10k+", label: "Unique Pieces" },
      { value: "48hr", label: "Delivery Time" }
    ]
  }
];

export default function HighlightsSection() {
  return (
    <section className="py-20 bg-[#F8F8F8]">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
            EVENTIQUE Highlights
          </h2>
          <p className="max-w-3xl mx-auto text-[#4A4A4A]">
            Discover what makes our platform a game-changer in the fashion industry. We combine cutting-edge technology with fashion expertise to deliver an unparalleled experience.
          </p>
        </motion.div>

        <div className="space-y-24">
          {highlights.map((highlight, index) => (
            <div 
              key={index} 
              className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center`}
            >
              <motion.div 
                className="lg:w-1/2 mb-10 lg:mb-0 lg:px-8"
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h3 className="font-[Playfair_Display] text-2xl md:text-3xl font-bold text-[#222222] mb-4">
                  {highlight.title}
                </h3>
                <p className="text-[#4A4A4A] mb-6">
                  {highlight.description}
                </p>
                
                <div className="grid grid-cols-3 gap-4 mt-8">
                  {highlight.stats.map((stat, statIndex) => (
                    <div key={statIndex} className="text-center">
                      <div className="font-[Montserrat] text-3xl font-bold text-[#222222]">{stat.value}</div>
                      <div className="text-sm text-[#888888]">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div 
                className="lg:w-1/2"
                initial={{ opacity: 0, x: index % 2 === 0 ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="relative rounded-2xl overflow-hidden shadow-xl">
                  <img 
                    src={highlight.imageUrl} 
                    alt={highlight.title} 
                    className="w-full h-[450px] object-cover" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[rgba(34,34,34,0.6)] to-transparent opacity-60"></div>
                </div>
              </motion.div>
            </div>
          ))}
        </div>

        <motion.div 
          className="mt-24 bg-white rounded-2xl shadow-lg p-8 md:p-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-[#E8C8A9] bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-8 w-8 text-[#E8C8A9]" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
              <div className="font-[Montserrat] text-3xl font-bold text-[#222222] mb-1">250k+</div>
              <div className="text-sm text-[#888888]">Active Users</div>
            </div>
            
            <div className="text-center">
              <div className="bg-[#E8C8A9] bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-8 w-8 text-[#E8C8A9]" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
              </div>
              <div className="font-[Montserrat] text-3xl font-bold text-[#222222] mb-1">15k+</div>
              <div className="text-sm text-[#888888]">Monthly Rentals</div>
            </div>
            
            <div className="text-center">
              <div className="bg-[#E8C8A9] bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-8 w-8 text-[#E8C8A9]" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div className="font-[Montserrat] text-3xl font-bold text-[#222222] mb-1">94%</div>
              <div className="text-sm text-[#888888]">Satisfaction Rate</div>
            </div>
            
            <div className="text-center">
              <div className="bg-[#E8C8A9] bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-8 w-8 text-[#E8C8A9]" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="font-[Montserrat] text-3xl font-bold text-[#222222] mb-1">28</div>
              <div className="text-sm text-[#888888]">Countries Served</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
