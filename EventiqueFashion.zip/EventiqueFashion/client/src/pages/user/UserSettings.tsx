import { useState } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  Bell, 
  Mail, 
  Smartphone, 
  Moon, 
  Palette, 
  Globe, 
  Shield, 
  DownloadCloud, 
  AlertTriangle,
  User
} from "lucide-react";

export default function UserSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    smsNotifications: false,
    eventReminders: true,
    newReleases: true,
    specialOffers: true,
  });
  
  const [displaySettings, setDisplaySettings] = useState({
    theme: "light",
    colorScheme: "default",
    reduceMotion: false,
    fontSize: "medium",
  });
  
  const [privacySettings, setPrivacySettings] = useState({
    shareUsageData: true,
    personalizationEnabled: true,
    locationServices: false,
  });

  const handleNotificationToggle = (setting: keyof typeof notificationSettings) => {
    setNotificationSettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };

  const handlePrivacyToggle = (setting: keyof typeof privacySettings) => {
    setPrivacySettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };

  const handleDisplayToggle = (setting: keyof typeof displaySettings) => {
    if (typeof displaySettings[setting] === 'boolean') {
      setDisplaySettings(prev => ({
        ...prev,
        [setting]: !prev[setting]
      }));
    }
  };

  const handleDisplayChange = (setting: keyof typeof displaySettings, value: string) => {
    setDisplaySettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const handleDeleteAccount = () => {
    toast({
      title: "Request received",
      description: "We've sent instructions to your email to confirm account deletion.",
    });
  };

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Settings</title>
      </Helmet>
      
      <div className="py-10 bg-[#F8F8F8] min-h-screen">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
              Settings
            </h1>
            <p className="max-w-2xl mx-auto text-[#4A4A4A]">
              Customize your preferences and manage your account settings.
            </p>
          </motion.div>
          
          <div className="max-w-4xl mx-auto">
            {/* Notification Settings */}
            <motion.div 
              className="bg-white rounded-2xl shadow-md p-6 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <div className="flex items-center mb-6">
                <Bell className="h-6 w-6 text-[#E8C8A9] mr-3" />
                <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222]">
                  Notification Preferences
                </h2>
              </div>
              
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div className="flex items-start">
                    <Mail className="h-5 w-5 text-[#888888] mt-1 mr-3" />
                    <div>
                      <h3 className="font-medium text-[#222222]">Email Notifications</h3>
                      <p className="text-sm text-[#888888]">Receive emails about your account, orders, and special offers</p>
                    </div>
                  </div>
                  <Switch 
                    checked={notificationSettings.emailNotifications} 
                    onCheckedChange={() => handleNotificationToggle("emailNotifications")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div className="flex items-start">
                    <Bell className="h-5 w-5 text-[#888888] mt-1 mr-3" />
                    <div>
                      <h3 className="font-medium text-[#222222]">Push Notifications</h3>
                      <p className="text-sm text-[#888888]">Receive alerts within the app or on your desktop</p>
                    </div>
                  </div>
                  <Switch 
                    checked={notificationSettings.pushNotifications} 
                    onCheckedChange={() => handleNotificationToggle("pushNotifications")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div className="flex items-start">
                    <Smartphone className="h-5 w-5 text-[#888888] mt-1 mr-3" />
                    <div>
                      <h3 className="font-medium text-[#222222]">SMS Notifications</h3>
                      <p className="text-sm text-[#888888]">Receive text messages about your orders and account updates</p>
                    </div>
                  </div>
                  <Switch 
                    checked={notificationSettings.smsNotifications} 
                    onCheckedChange={() => handleNotificationToggle("smsNotifications")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div className="pt-4 border-t border-[#E1E1E1]">
                  <h3 className="font-medium text-[#222222] mb-4">Notification Types</h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <p className="text-[#4A4A4A]">Event Reminders</p>
                      <Switch 
                        checked={notificationSettings.eventReminders} 
                        onCheckedChange={() => handleNotificationToggle("eventReminders")} 
                        className="data-[state=checked]:bg-[#E8C8A9]"
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <p className="text-[#4A4A4A]">New Releases & Collections</p>
                      <Switch 
                        checked={notificationSettings.newReleases} 
                        onCheckedChange={() => handleNotificationToggle("newReleases")} 
                        className="data-[state=checked]:bg-[#E8C8A9]"
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <p className="text-[#4A4A4A]">Special Offers & Promotions</p>
                      <Switch 
                        checked={notificationSettings.specialOffers} 
                        onCheckedChange={() => handleNotificationToggle("specialOffers")} 
                        className="data-[state=checked]:bg-[#E8C8A9]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Display Settings */}
            <motion.div 
              className="bg-white rounded-2xl shadow-md p-6 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.1 }}
            >
              <div className="flex items-center mb-6">
                <Palette className="h-6 w-6 text-[#E8C8A9] mr-3" />
                <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222]">
                  Display Preferences
                </h2>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-[#222222] mb-3">Theme</h3>
                  <RadioGroup 
                    value={displaySettings.theme} 
                    onValueChange={(value) => handleDisplayChange("theme", value)}
                    className="flex flex-col space-y-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="light" id="theme-light" />
                      <Label htmlFor="theme-light">Light</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="dark" id="theme-dark" />
                      <Label htmlFor="theme-dark">Dark</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="system" id="theme-system" />
                      <Label htmlFor="theme-system">Use System Setting</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div>
                  <h3 className="font-medium text-[#222222] mb-3">Color Scheme</h3>
                  <div className="grid grid-cols-5 gap-2">
                    {[
                      { id: "default", color: "#E8C8A9" },
                      { id: "blue", color: "#3B82F6" },
                      { id: "green", color: "#10B981" },
                      { id: "purple", color: "#8B5CF6" },
                      { id: "rose", color: "#F43F5E" },
                    ].map((scheme) => (
                      <div 
                        key={scheme.id}
                        className={`w-10 h-10 rounded-full cursor-pointer ${
                          displaySettings.colorScheme === scheme.id ? "ring-2 ring-offset-2 ring-[#222222]" : ""
                        }`}
                        style={{ backgroundColor: scheme.color }}
                        onClick={() => handleDisplayChange("colorScheme", scheme.id)}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div>
                    <h3 className="font-medium text-[#222222]">Reduce Motion</h3>
                    <p className="text-sm text-[#888888]">Minimize animations and transitions</p>
                  </div>
                  <Switch 
                    checked={displaySettings.reduceMotion} 
                    onCheckedChange={() => handleDisplayToggle("reduceMotion")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div>
                  <h3 className="font-medium text-[#222222] mb-3">Font Size</h3>
                  <RadioGroup 
                    value={displaySettings.fontSize} 
                    onValueChange={(value) => handleDisplayChange("fontSize", value)}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="small" id="font-small" />
                      <Label htmlFor="font-small" className="text-sm">Small</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="font-medium" />
                      <Label htmlFor="font-medium">Medium</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="large" id="font-large" />
                      <Label htmlFor="font-large" className="text-lg">Large</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </motion.div>
            
            {/* Privacy & Data Settings */}
            <motion.div 
              className="bg-white rounded-2xl shadow-md p-6 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
            >
              <div className="flex items-center mb-6">
                <Shield className="h-6 w-6 text-[#E8C8A9] mr-3" />
                <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222]">
                  Privacy & Data
                </h2>
              </div>
              
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div className="flex items-start">
                    <Globe className="h-5 w-5 text-[#888888] mt-1 mr-3" />
                    <div>
                      <h3 className="font-medium text-[#222222]">Share Usage Data</h3>
                      <p className="text-sm text-[#888888]">Help us improve EVENTIQUE by sharing anonymous usage data</p>
                    </div>
                  </div>
                  <Switch 
                    checked={privacySettings.shareUsageData} 
                    onCheckedChange={() => handlePrivacyToggle("shareUsageData")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div className="flex items-start">
                    <Palette className="h-5 w-5 text-[#888888] mt-1 mr-3" />
                    <div>
                      <h3 className="font-medium text-[#222222]">Personalization</h3>
                      <p className="text-sm text-[#888888]">Allow EVENTIQUE to use your preferences to personalize your experience</p>
                    </div>
                  </div>
                  <Switch 
                    checked={privacySettings.personalizationEnabled} 
                    onCheckedChange={() => handlePrivacyToggle("personalizationEnabled")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                  <div className="flex items-start">
                    <Globe className="h-5 w-5 text-[#888888] mt-1 mr-3" />
                    <div>
                      <h3 className="font-medium text-[#222222]">Location Services</h3>
                      <p className="text-sm text-[#888888]">Allow EVENTIQUE to access your location</p>
                    </div>
                  </div>
                  <Switch 
                    checked={privacySettings.locationServices} 
                    onCheckedChange={() => handlePrivacyToggle("locationServices")} 
                    className="data-[state=checked]:bg-[#E8C8A9]"
                  />
                </div>
                
                <div className="pt-4 border-t border-[#E1E1E1]">
                  <h3 className="font-medium text-[#222222] mb-4">Data Management</h3>
                  
                  <div className="space-y-4">
                    <Button variant="outline" className="w-full justify-start">
                      <DownloadCloud className="mr-2 h-4 w-4" />
                      Request Data Export
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Account Management */}
            <motion.div 
              className="bg-white rounded-2xl shadow-md p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3 }}
            >
              <div className="flex items-center mb-6">
                <User className="h-6 w-6 text-[#E8C8A9] mr-3" />
                <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222]">
                  Account Management
                </h2>
              </div>
              
              <div className="space-y-6">
                <div className="bg-[#F8F8F8] p-4 rounded-lg border border-[#E1E1E1]">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-[#D64045] mr-3 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium text-[#222222]">Delete Account</h3>
                      <p className="text-sm text-[#888888] mt-1 mb-4">This action is irreversible and will permanently delete all your data, including profile information, rental history, and saved preferences.</p>
                      <Button 
                        variant="destructive"
                        onClick={handleDeleteAccount}
                      >
                        Delete Account
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <div className="text-center mt-8">
              <Button 
                className="bg-[#222222] hover:bg-[#2A2A2A] text-white px-8"
                onClick={handleSaveSettings}
              >
                Save All Settings
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}