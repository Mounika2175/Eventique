import { useState } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, Filter, Search, ShoppingBag, Star, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { fashionCategories } from "@/lib/data";

// Sample fashion rental data
const rentalItems = [
  {
    id: 1,
    name: "Elegant Black Tuxedo",
    description: "Classic black tuxedo perfect for formal events and galas.",
    price: 12900,
    duration: "3-day rental",
    rating: 4.8,
    reviews: 42,
    image: "https://images.unsplash.com/photo-1590400516695-36708d3f964a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    category: "formal",
    brand: "Hugo Boss",
    size: ["S", "M", "L", "XL"],
    colors: ["Black"],
    badge: { text: "Designer", type: "designer" }
  },
  {
    id: 2,
    name: "Floral Summer Dress",
    description: "Light and airy floral dress, perfect for summer garden parties.",
    price: 7500,
    duration: "4-day rental",
    rating: 4.6,
    reviews: 28,
    image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=446&q=80",
    category: "casual",
    brand: "Free People",
    size: ["XS", "S", "M", "L"],
    colors: ["Multicolor"],
    badge: { text: "New Arrival", type: "available" }
  },
  {
    id: 3,
    name: "Navy Blue Blazer",
    description: "Tailored navy blazer suitable for business meetings and semi-formal events.",
    price: 8500,
    duration: "5-day rental",
    rating: 4.7,
    reviews: 36,
    image: "https://images.unsplash.com/photo-1598808503746-f34faed738a3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    category: "business",
    brand: "Brooks Brothers",
    size: ["S", "M", "L", "XL", "XXL"],
    colors: ["Navy"],
    badge: { text: "Limited Stock", type: "limited" }
  },
  {
    id: 4,
    name: "Sequin Evening Gown",
    description: "Stunning sequin gown that makes a statement at any formal occasion.",
    price: 15900,
    duration: "3-day rental",
    rating: 4.9,
    reviews: 54,
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    category: "formal",
    brand: "Badgley Mischka",
    size: ["XS", "S", "M", "L"],
    colors: ["Silver", "Gold"],
    badge: { text: "Premium", type: "premium" }
  },
  {
    id: 5,
    name: "Casual Linen Shirt",
    description: "Comfortable linen shirt for a relaxed yet stylish look.",
    price: 4900,
    duration: "7-day rental",
    rating: 4.5,
    reviews: 31,
    image: "https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    category: "casual",
    brand: "J.Crew",
    size: ["S", "M", "L", "XL"],
    colors: ["White", "Blue", "Beige"],
    badge: null
  },
  {
    id: 6,
    name: "Designer Handbag",
    description: "Luxury designer handbag to complement any outfit for special occasions.",
    price: 9900,
    duration: "5-day rental",
    rating: 4.8,
    reviews: 47,
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    category: "accessories",
    brand: "Gucci",
    size: ["One Size"],
    colors: ["Black", "Tan"],
    badge: { text: "Designer", type: "designer" }
  },
  {
    id: 7,
    name: "Winter Wool Coat",
    description: "Stylish wool coat to keep you warm and fashionable during winter events.",
    price: 10900,
    duration: "7-day rental",
    rating: 4.7,
    reviews: 29,
    image: "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
    category: "outerwear",
    brand: "Burberry",
    size: ["S", "M", "L"],
    colors: ["Black", "Camel", "Grey"],
    badge: { text: "Limited Stock", type: "limited" }
  },
  {
    id: 8,
    name: "Cocktail Dress",
    description: "Elegant cocktail dress perfect for semi-formal parties and events.",
    price: 8900,
    duration: "4-day rental",
    rating: 4.6,
    reviews: 38,
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=483&q=80",
    category: "party",
    brand: "Reformation",
    size: ["XS", "S", "M", "L"],
    colors: ["Red", "Black", "Navy"],
    badge: { text: "New Arrival", type: "available" }
  }
];

// User rental history
const rentalHistory = [
  {
    id: 101,
    itemId: 1,
    itemName: "Elegant Black Tuxedo",
    image: "https://images.unsplash.com/photo-1590400516695-36708d3f964a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    rentalDate: "2023-09-15",
    returnDate: "2023-09-18",
    status: "Completed",
    price: 12900
  },
  {
    id: 102,
    itemId: 4,
    itemName: "Sequin Evening Gown",
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80",
    rentalDate: "2023-09-28",
    returnDate: "2023-10-01",
    status: "Active",
    price: 15900
  }
];

export default function FashionRentalPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [activeTab, setActiveTab] = useState("browse");
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedFilters, setSelectedFilters] = useState({
    categories: [] as string[],
    prices: [] as string[],
    sizes: [] as string[],
  });
  const [searchQuery, setSearchQuery] = useState("");
  
  // For a real app, we would fetch these from the API
  const { data: items } = useQuery({
    queryKey: ['/api/fashion-items'],
    queryFn: async () => rentalItems,
  });

  const { data: history } = useQuery({
    queryKey: ['/api/rentals/user', user?.id],
    queryFn: async () => rentalHistory,
    enabled: !!user?.id
  });

  const handleRentalSubmit = () => {
    toast({
      title: "Rental request submitted",
      description: `Your rental for ${selectedItem.name} has been confirmed.`,
    });
    setSelectedItem(null);
  };

  const toggleFilter = (type: keyof typeof selectedFilters, value: string) => {
    setSelectedFilters(prev => {
      const currentFilters = [...prev[type]];
      const index = currentFilters.indexOf(value);
      
      if (index === -1) {
        // Add the filter
        return { ...prev, [type]: [...currentFilters, value] };
      } else {
        // Remove the filter
        currentFilters.splice(index, 1);
        return { ...prev, [type]: currentFilters };
      }
    });
  };

  const filteredItems = () => {
    if (!items) return [];
    
    return items.filter(item => {
      // Filter by search query
      if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
          !item.description.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      
      // Filter by category
      if (selectedFilters.categories.length > 0 && 
          !selectedFilters.categories.includes(item.category)) {
        return false;
      }
      
      // Filter by price
      if (selectedFilters.prices.length > 0) {
        const itemPrice = item.price / 100;
        let matchesPrice = false;
        
        for (const priceRange of selectedFilters.prices) {
          if (priceRange === "under50" && itemPrice < 50) {
            matchesPrice = true;
            break;
          } else if (priceRange === "50to100" && itemPrice >= 50 && itemPrice <= 100) {
            matchesPrice = true;
            break;
          } else if (priceRange === "100to200" && itemPrice > 100 && itemPrice <= 200) {
            matchesPrice = true;
            break;
          } else if (priceRange === "over200" && itemPrice > 200) {
            matchesPrice = true;
            break;
          }
        }
        
        if (!matchesPrice) return false;
      }
      
      // Filter by size
      if (selectedFilters.sizes.length > 0) {
        let matchesSize = false;
        
        for (const size of selectedFilters.sizes) {
          if (item.size.includes(size)) {
            matchesSize = true;
            break;
          }
        }
        
        if (!matchesSize) return false;
      }
      
      return true;
    });
  };

  const getColorForBadge = (type: string | undefined) => {
    if (!type) return '';
    
    switch (type) {
      case 'designer': return 'bg-[#222222] text-white';
      case 'available': return 'bg-[#2E8B57] text-white';
      case 'limited': return 'bg-[#FF6B6B] text-white';
      case 'premium': return 'bg-[#8B5CF6] text-white';
      default: return 'bg-[#888888] text-white';
    }
  };

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Fashion Rentals</title>
      </Helmet>
      
      <div className="py-10 bg-[#F8F8F8] min-h-screen">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
              Premium Fashion Rentals
            </h1>
            <p className="max-w-2xl mx-auto text-[#4A4A4A]">
              Rent designer pieces for your special events at a fraction of the retail price.
            </p>
          </motion.div>
          
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="browse">Browse Rentals</TabsTrigger>
              <TabsTrigger value="history">Your Rentals</TabsTrigger>
            </TabsList>
            
            <TabsContent value="browse">
              <div className="flex flex-col space-y-6">
                {/* Search and Filter Controls */}
                <div className="flex flex-col md:flex-row justify-between gap-4 mb-4">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Search className="h-5 w-5 text-[#888888]" />
                    </div>
                    <Input
                      className="pl-10"
                      placeholder="Search rentals..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <Button
                    variant="outline"
                    className="flex items-center space-x-2"
                    onClick={() => setFilterOpen(!filterOpen)}
                  >
                    <Filter className="h-4 w-4" />
                    <span>Filters</span>
                    {(selectedFilters.categories.length > 0 || 
                      selectedFilters.prices.length > 0 || 
                      selectedFilters.sizes.length > 0) && (
                      <span className="ml-1 w-5 h-5 bg-[#E8C8A9] text-[#222222] rounded-full text-xs flex items-center justify-center">
                        {selectedFilters.categories.length + selectedFilters.prices.length + selectedFilters.sizes.length}
                      </span>
                    )}
                  </Button>
                </div>
                
                {/* Filters */}
                {filterOpen && (
                  <motion.div 
                    className="bg-white p-6 rounded-lg shadow-md mb-6"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Categories */}
                      <div>
                        <h3 className="font-medium text-[#222222] mb-4">Categories</h3>
                        <div className="space-y-2">
                          {["formal", "casual", "business", "party", "outerwear", "accessories"].map((category) => (
                            <div key={category} className="flex items-center">
                              <input
                                type="checkbox"
                                id={`category-${category}`}
                                className="rounded border-[#E1E1E1] text-[#E8C8A9] focus:ring-[#E8C8A9]"
                                checked={selectedFilters.categories.includes(category)}
                                onChange={() => toggleFilter("categories", category)}
                              />
                              <label htmlFor={`category-${category}`} className="ml-2 text-[#4A4A4A] capitalize">
                                {category}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Price Ranges */}
                      <div>
                        <h3 className="font-medium text-[#222222] mb-4">Price Range</h3>
                        <div className="space-y-2">
                          {[
                            { id: "under50", label: "Under $50" },
                            { id: "50to100", label: "$50 - $100" },
                            { id: "100to200", label: "$100 - $200" },
                            { id: "over200", label: "Over $200" }
                          ].map((price) => (
                            <div key={price.id} className="flex items-center">
                              <input
                                type="checkbox"
                                id={`price-${price.id}`}
                                className="rounded border-[#E1E1E1] text-[#E8C8A9] focus:ring-[#E8C8A9]"
                                checked={selectedFilters.prices.includes(price.id)}
                                onChange={() => toggleFilter("prices", price.id)}
                              />
                              <label htmlFor={`price-${price.id}`} className="ml-2 text-[#4A4A4A]">
                                {price.label}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Sizes */}
                      <div>
                        <h3 className="font-medium text-[#222222] mb-4">Sizes</h3>
                        <div className="space-y-2">
                          {["XS", "S", "M", "L", "XL", "XXL"].map((size) => (
                            <div key={size} className="flex items-center">
                              <input
                                type="checkbox"
                                id={`size-${size}`}
                                className="rounded border-[#E1E1E1] text-[#E8C8A9] focus:ring-[#E8C8A9]"
                                checked={selectedFilters.sizes.includes(size)}
                                onChange={() => toggleFilter("sizes", size)}
                              />
                              <label htmlFor={`size-${size}`} className="ml-2 text-[#4A4A4A]">
                                {size}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-end mt-6">
                      <Button
                        variant="outline"
                        className="mr-2"
                        onClick={() => {
                          setSelectedFilters({
                            categories: [],
                            prices: [],
                            sizes: [],
                          });
                        }}
                      >
                        Clear All
                      </Button>
                      <Button
                        className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                        onClick={() => setFilterOpen(false)}
                      >
                        Apply Filters
                      </Button>
                    </div>
                  </motion.div>
                )}
                
                {/* Items Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredItems().map((item) => (
                    <motion.div
                      key={item.id}
                      className="group relative bg-white rounded-2xl shadow-md overflow-hidden"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4 }}
                    >
                      <div className="relative aspect-[2/3] overflow-hidden">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        {item.badge && (
                          <div className={`absolute top-4 left-4 ${getColorForBadge(item.badge.type)} text-xs px-2 py-1 rounded`}>
                            {item.badge.text}
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-70 transition-opacity"></div>
                        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                className="w-full bg-[#E8C8A9] text-[#222222] hover:bg-[#d6b089]"
                                onClick={() => setSelectedItem(item)}
                              >
                                Quick View
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-4xl">
                              <DialogHeader>
                                <DialogTitle className="text-2xl font-[Playfair_Display]">{item.name}</DialogTitle>
                                <DialogDescription>{item.description}</DialogDescription>
                              </DialogHeader>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                                <div className="aspect-[2/3] bg-[#F8F8F8] rounded-lg overflow-hidden">
                                  <img
                                    src={item.image}
                                    alt={item.name}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                
                                <div className="space-y-4">
                                  <div className="flex justify-between items-center">
                                    <div>
                                      <p className="text-[#222222] font-bold text-2xl">
                                        ${(item.price / 100).toFixed(2)}
                                      </p>
                                      <p className="text-[#888888]">{item.duration}</p>
                                    </div>
                                    <div className="flex items-center">
                                      <Star className="h-4 w-4 fill-[#E8C8A9] text-[#E8C8A9] mr-1" />
                                      <span className="font-medium">{item.rating}</span>
                                      <span className="text-[#888888] text-sm ml-1">({item.reviews})</span>
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <h4 className="text-[#222222] font-medium mb-2">Brand</h4>
                                    <p>{item.brand}</p>
                                  </div>
                                  
                                  <div>
                                    <h4 className="text-[#222222] font-medium mb-2">Available Sizes</h4>
                                    <div className="flex flex-wrap gap-2">
                                      {item.size.map((size) => (
                                        <div 
                                          key={size} 
                                          className="w-10 h-10 rounded-full border border-[#E1E1E1] flex items-center justify-center text-sm"
                                        >
                                          {size}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <h4 className="text-[#222222] font-medium mb-2">Colors</h4>
                                    <div className="flex gap-2">
                                      {item.colors.map((color) => (
                                        <div key={color} className="text-sm">{color}</div>
                                      ))}
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <h4 className="text-[#222222] font-medium mb-2">Select Rental Dates</h4>
                                    <div className="bg-[#F8F8F8] p-4 rounded-lg">
                                      <div className="flex flex-col space-y-4">
                                        <div className="grid grid-cols-2 gap-4">
                                          <div>
                                            <Label htmlFor="start-date">Start Date</Label>
                                            <div className="relative mt-1">
                                              <Input 
                                                id="start-date" 
                                                placeholder="Select date" 
                                                className="pl-10"
                                              />
                                              <CalendarIcon className="absolute left-3 top-2.5 h-5 w-5 text-[#888888]" />
                                            </div>
                                          </div>
                                          <div>
                                            <Label htmlFor="end-date">End Date</Label>
                                            <div className="relative mt-1">
                                              <Input 
                                                id="end-date" 
                                                placeholder="Select date" 
                                                className="pl-10"
                                              />
                                              <CalendarIcon className="absolute left-3 top-2.5 h-5 w-5 text-[#888888]" />
                                            </div>
                                          </div>
                                        </div>
                                        <div>
                                          <Label htmlFor="size">Size</Label>
                                          <select id="size" className="w-full border border-[#E1E1E1] rounded-md p-2 mt-1">
                                            <option value="" disabled selected>Select Size</option>
                                            {item.size.map((size) => (
                                              <option key={size} value={size}>{size}</option>
                                            ))}
                                          </select>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              <DialogFooter>
                                <Button 
                                  variant="outline" 
                                  className="w-full md:w-auto"
                                  onClick={() => setSelectedItem(null)}
                                >
                                  Cancel
                                </Button>
                                <Button 
                                  className="w-full md:w-auto bg-[#222222] hover:bg-[#2A2A2A] text-white"
                                  onClick={handleRentalSubmit}
                                >
                                  Rent Now
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <h3 className="font-medium text-[#222222] truncate">{item.name}</h3>
                        <div className="flex justify-between items-center mt-1">
                          <p className="text-[#888888]">{item.duration}</p>
                          <p className="font-semibold text-[#222222]">${(item.price / 100).toFixed(2)}</p>
                        </div>
                        <div className="flex items-center mt-2">
                          <div className="flex text-[#E8C8A9]">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-4 w-4 ${star <= Math.floor(item.rating) ? 'fill-[#E8C8A9]' : 'fill-none'}`}
                              />
                            ))}
                          </div>
                          <span className="text-xs text-[#888888] ml-1">({item.reviews})</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
                
                {filteredItems().length === 0 && (
                  <div className="text-center py-16 bg-white rounded-2xl shadow-md">
                    <ShoppingBag className="h-16 w-16 text-[#E1E1E1] mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-[#222222] mb-2">No items found</h3>
                    <p className="text-[#888888] mb-6">Try adjusting your filters or search criteria</p>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedFilters({
                          categories: [],
                          prices: [],
                          sizes: [],
                        });
                      }}
                    >
                      Clear All Filters
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="history">
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-6">
                  Your Rental History
                </h2>
                
                {history && history.length > 0 ? (
                  <div className="space-y-6">
                    {history.map((rental) => (
                      <div key={rental.id} className="flex flex-col md:flex-row items-start md:items-center gap-4 p-4 border border-[#E1E1E1] rounded-lg">
                        <div className="w-20 h-20 rounded-md overflow-hidden bg-[#F8F8F8] flex-shrink-0">
                          <img
                            src={rental.image}
                            alt={rental.itemName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-medium text-[#222222]">{rental.itemName}</h3>
                          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 mt-1">
                            <p className="text-sm text-[#888888]">
                              ${(rental.price / 100).toFixed(2)}
                            </p>
                            <div className="flex items-center text-sm">
                              <p className="text-[#888888]">
                                {new Date(rental.rentalDate).toLocaleDateString()} - {new Date(rental.returnDate).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="md:text-right">
                          <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium
                            ${rental.status === 'Completed' ? 'bg-[#2E8B57] bg-opacity-10 text-[#2E8B57]' : 
                              rental.status === 'Active' ? 'bg-[#3B82F6] bg-opacity-10 text-[#3B82F6]' :
                              'bg-[#888888] bg-opacity-10 text-[#888888]'
                            }`}
                          >
                            {rental.status}
                          </span>
                          
                          {rental.status === 'Completed' && (
                            <button className="block mt-2 text-sm text-[#888888] hover:text-[#222222]">
                              Write a Review
                            </button>
                          )}
                          
                          {rental.status === 'Active' && (
                            <div className="flex items-center mt-2 text-sm text-[#888888]">
                              <Truck className="h-4 w-4 mr-1" />
                              <span>Return by {new Date(rental.returnDate).toLocaleDateString()}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <ShoppingBag className="h-16 w-16 text-[#E1E1E1] mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-[#222222] mb-2">No rental history</h3>
                    <p className="text-[#888888] mb-6">You haven't rented any items yet</p>
                    <Button 
                      className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                      onClick={() => setActiveTab("browse")}
                    >
                      Browse Rentals
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}