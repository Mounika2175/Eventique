import { useState } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Avatar form schema for body measurements
const avatarSchema = z.object({
  height: z.number().min(150, "Height must be at least 150cm").max(220, "Height must be at most 220cm"),
  weight: z.number().min(40, "Weight must be at least 40kg").max(150, "Weight must be at most 150kg"),
  bodyType: z.enum(["slim", "athletic", "average", "curvy", "plus"]),
  shoulderWidth: z.number().min(1).max(10),
  chestSize: z.number().min(1).max(10),
  waistSize: z.number().min(1).max(10),
  hipSize: z.number().min(1).max(10),
  skinTone: z.enum(["light", "medium", "tan", "dark", "deep"]),
});

type AvatarFormValues = z.infer<typeof avatarSchema>;

export default function AvatarCreator() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("body");
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState("/placeholder-avatar.jpg");

  const form = useForm<AvatarFormValues>({
    resolver: zodResolver(avatarSchema),
    defaultValues: {
      height: 170,
      weight: 70,
      bodyType: "average",
      shoulderWidth: 5,
      chestSize: 5,
      waistSize: 5,
      hipSize: 5,
      skinTone: "medium",
    },
  });

  const onSubmit = async (data: AvatarFormValues) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to create your avatar",
        variant: "destructive",
      });
      return;
    }

    try {
      // In a real application, we would send the data to the server
      // For now, we're just simulating a successful submission
      
      // Simulated API call
      // const response = await apiRequest("POST", "/api/avatars", {
      //   userId: user.id,
      //   ...data,
      // });
      
      toast({
        title: "Avatar created successfully",
        description: "Your virtual fashion twin is now ready to use!",
      });
      
      // Move to the next tab
      setActiveTab("appearance");
    } catch (error) {
      toast({
        title: "Failed to create avatar",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const categoryItems = ["Tops", "Bottoms", "Shoes", "Accessories"];
  const bodyTypeDescriptions = {
    slim: "Lean physical build with less defined curves.",
    athletic: "More muscular with broader shoulders and narrower hips.",
    average: "Balanced proportions with moderate curves.",
    curvy: "More defined curves with proportional bust, waist, and hips.",
    plus: "Fuller figure with rounder contours throughout the body.",
  };

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Create Your Virtual Avatar</title>
      </Helmet>
      
      <div className="py-10 bg-[#F8F8F8] min-h-screen">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
              Create Your Digital Fashion Twin
            </h1>
            <p className="max-w-2xl mx-auto text-[#4A4A4A]">
              Build an accurate digital representation of yourself for virtual try-ons and personalized fashion recommendations.
            </p>
          </motion.div>
          
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Avatar Preview */}
            <motion.div 
              className="lg:w-1/3"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
                <h2 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-4">
                  Your Avatar Preview
                </h2>
                
                <div className="aspect-[3/4] rounded-xl overflow-hidden bg-[#222222] flex items-center justify-center mb-6">
                  <div className="text-center p-6">
                    <div className="w-24 h-24 mx-auto mb-4 rounded-full border-2 border-dashed border-[#E8C8A9] flex items-center justify-center">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        className="h-12 w-12 text-[#E8C8A9]" 
                        fill="none" 
                        viewBox="0 0 24 24" 
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <p className="text-[#E1E1E1] text-lg">Your 3D Avatar</p>
                    <p className="text-[#888888] text-sm mt-2">As you make selections, your avatar will update</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-4 gap-4">
                  {categoryItems.map((item, index) => (
                    <div key={index} className="bg-[#F8F8F8] rounded-lg p-2 cursor-pointer hover:bg-[#E8C8A9] hover:bg-opacity-20 transition-colors">
                      <div className="aspect-square rounded-md bg-[#E1E1E1] flex items-center justify-center">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          className="h-6 w-6 text-[#888888]" 
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor"
                        >
                          {index === 0 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 13h10l2-9H5l2 9zm0 0v6h10v-6" />}
                          {index === 1 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 6v12m0 0H5m4 0h6m2-12v12m0-12h4m-4 0H9" />}
                          {index === 2 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />}
                          {index === 3 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-.553.894L15 19m0-9l-9-4.5v10.5l9 4.5V10z" />}
                        </svg>
                      </div>
                      <p className="text-xs text-center mt-1 text-[#4A4A4A]">{item}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
            
            {/* Avatar Creator Form */}
            <motion.div 
              className="lg:w-2/3"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="bg-white rounded-2xl shadow-md p-6">
                <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-8">
                    <TabsTrigger value="body">Body Measurements</TabsTrigger>
                    <TabsTrigger value="appearance">Appearance</TabsTrigger>
                    <TabsTrigger value="style">Style Preferences</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="body">
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="height"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Height (cm)</FormLabel>
                                <FormControl>
                                  <div className="flex items-center space-x-4">
                                    <Slider
                                      min={150}
                                      max={220}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={(vals) => field.onChange(vals[0])}
                                      className="flex-1"
                                    />
                                    <Input
                                      type="number"
                                      className="w-16"
                                      value={field.value}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Weight (kg)</FormLabel>
                                <FormControl>
                                  <div className="flex items-center space-x-4">
                                    <Slider
                                      min={40}
                                      max={150}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={(vals) => field.onChange(vals[0])}
                                      className="flex-1"
                                    />
                                    <Input
                                      type="number"
                                      className="w-16"
                                      value={field.value}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="bodyType"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Body Type</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="grid grid-cols-1 md:grid-cols-3 gap-4"
                                >
                                  {(["slim", "athletic", "average", "curvy", "plus"] as const).map((type) => (
                                    <FormItem key={type} className="flex items-center space-x-2">
                                      <FormControl>
                                        <RadioGroupItem value={type} id={type} />
                                      </FormControl>
                                      <div>
                                        <FormLabel htmlFor={type} className="text-base font-medium capitalize">
                                          {type}
                                        </FormLabel>
                                        <p className="text-xs text-[#888888]">
                                          {bodyTypeDescriptions[type]}
                                        </p>
                                      </div>
                                    </FormItem>
                                  ))}
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="space-y-4">
                          <h3 className="text-lg font-medium text-[#222222]">Detailed Measurements</h3>
                          <p className="text-sm text-[#888888] mb-4">
                            These measurements help us create a more accurate virtual representation for clothing fit.
                          </p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                              control={form.control}
                              name="shoulderWidth"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Shoulder Width</FormLabel>
                                  <FormControl>
                                    <Slider
                                      min={1}
                                      max={10}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={(vals) => field.onChange(vals[0])}
                                    />
                                  </FormControl>
                                  <div className="flex justify-between text-xs pt-1">
                                    <span>Narrow</span>
                                    <span>Wide</span>
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="chestSize"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Chest Size</FormLabel>
                                  <FormControl>
                                    <Slider
                                      min={1}
                                      max={10}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={(vals) => field.onChange(vals[0])}
                                    />
                                  </FormControl>
                                  <div className="flex justify-between text-xs pt-1">
                                    <span>Small</span>
                                    <span>Large</span>
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="waistSize"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Waist Size</FormLabel>
                                  <FormControl>
                                    <Slider
                                      min={1}
                                      max={10}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={(vals) => field.onChange(vals[0])}
                                    />
                                  </FormControl>
                                  <div className="flex justify-between text-xs pt-1">
                                    <span>Small</span>
                                    <span>Large</span>
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="hipSize"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Hip Size</FormLabel>
                                  <FormControl>
                                    <Slider
                                      min={1}
                                      max={10}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={(vals) => field.onChange(vals[0])}
                                    />
                                  </FormControl>
                                  <div className="flex justify-between text-xs pt-1">
                                    <span>Small</span>
                                    <span>Large</span>
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <div className="mt-8 flex justify-end">
                          <Button 
                            type="submit" 
                            className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                          >
                            Save & Continue
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </TabsContent>
                  
                  <TabsContent value="appearance">
                    <div className="space-y-6">
                      <h2 className="font-[Playfair_Display] text-xl font-semibold text-[#222222]">
                        Customize Your Appearance
                      </h2>
                      <p className="text-[#888888]">
                        Select your skin tone, hair color, and other physical characteristics for an accurate virtual representation.
                      </p>
                      
                      {/* Skin Tone Selection */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium text-[#222222]">Skin Tone</h3>
                        <div className="flex space-x-4">
                          {["light", "medium", "tan", "dark", "deep"].map((tone, index) => (
                            <div 
                              key={index} 
                              className={`w-12 h-12 rounded-full cursor-pointer transition-all ${
                                form.getValues("skinTone") === tone ? "ring-4 ring-[#E8C8A9]" : "ring-2 ring-transparent hover:ring-[#E1E1E1]"
                              }`}
                              style={{ 
                                backgroundColor: 
                                  tone === "light" ? "#F5E6DC" : 
                                  tone === "medium" ? "#E5C8A6" : 
                                  tone === "tan" ? "#C68E5B" : 
                                  tone === "dark" ? "#8D5A34" : 
                                  "#472C17" 
                              }}
                              onClick={() => form.setValue("skinTone", tone as any)}
                            />
                          ))}
                        </div>
                      </div>
                      
                      {/* Placeholder for other appearance options */}
                      <div className="space-y-4 opacity-60 pointer-events-none">
                        <h3 className="text-lg font-medium text-[#222222]">Hair Style</h3>
                        <div className="grid grid-cols-5 gap-4">
                          {[1, 2, 3, 4, 5].map((i) => (
                            <div key={i} className="aspect-square bg-[#F8F8F8] rounded-lg"></div>
                          ))}
                        </div>
                        
                        <h3 className="text-lg font-medium text-[#222222] mt-6">Hair Color</h3>
                        <div className="flex space-x-4">
                          {["#222222", "#864720", "#D4A76A", "#B87B45", "#999999"].map((color, index) => (
                            <div 
                              key={index} 
                              className="w-10 h-10 rounded-full ring-2 ring-[#E1E1E1]"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="text-center py-4 mt-4 bg-[#F8F8F8] rounded-lg">
                        <p className="text-[#888888] mb-2">Coming soon</p>
                        <p className="text-xs text-[#888888]">More customization options will be available in future updates</p>
                      </div>
                      
                      <div className="mt-8 flex justify-between">
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => setActiveTab("body")}
                        >
                          Back
                        </Button>
                        <Button 
                          type="button" 
                          className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                          onClick={() => setActiveTab("style")}
                        >
                          Next: Style Preferences
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="style">
                    <div className="space-y-6">
                      <h2 className="font-[Playfair_Display] text-xl font-semibold text-[#222222]">
                        Define Your Style Preferences
                      </h2>
                      <p className="text-[#888888]">
                        Help us understand your fashion taste to provide better recommendations and outfit suggestions.
                      </p>
                      
                      {/* Style Profile Selection */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium text-[#222222]">Your Style Profile</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {[
                            { name: "Modern Minimal", desc: "Clean lines, neutral colors, simple silhouettes" },
                            { name: "Business Casual", desc: "Professional yet approachable workplace attire" },
                            { name: "Vintage", desc: "Retro aesthetics with a modern twist" },
                            { name: "Bohemian", desc: "Free-spirited, layered looks with artistic flair" },
                            { name: "Athleisure", desc: "Sporty, comfortable pieces with street style appeal" },
                            { name: "Glamorous", desc: "Bold, statement pieces with luxurious details" },
                          ].map((style, index) => (
                            <div 
                              key={index} 
                              className="border border-[#E1E1E1] rounded-lg p-4 cursor-pointer hover:border-[#E8C8A9] hover:bg-[#E8C8A9] hover:bg-opacity-5 transition-all"
                            >
                              <h4 className="font-medium text-[#222222] mb-1">{style.name}</h4>
                              <p className="text-xs text-[#888888]">{style.desc}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Color Preferences */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium text-[#222222]">Color Preferences</h3>
                        <p className="text-sm text-[#888888]">Select colors you typically wear or prefer in your outfits</p>
                        
                        <div className="flex flex-wrap gap-3">
                          {[
                            { name: "Neutrals", color: "#F8F8F8" },
                            { name: "Black", color: "#222222" },
                            { name: "Blues", color: "#3B82F6" },
                            { name: "Greens", color: "#10B981" },
                            { name: "Yellows", color: "#F59E0B" },
                            { name: "Reds", color: "#EF4444" },
                            { name: "Purples", color: "#8B5CF6" },
                          ].map((color, index) => (
                            <div 
                              key={index} 
                              className="flex items-center space-x-2 border border-[#E1E1E1] rounded-full px-3 py-1 cursor-pointer hover:border-[#E8C8A9] transition-all"
                            >
                              <div 
                                className="w-4 h-4 rounded-full"
                                style={{ backgroundColor: color.color }}
                              />
                              <span className="text-sm">{color.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Placeholder for other style options */}
                      <div className="space-y-4 opacity-60 pointer-events-none">
                        <h3 className="text-lg font-medium text-[#222222]">Preferred Brands</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {[1, 2, 3, 4].map((i) => (
                            <div key={i} className="h-12 bg-[#F8F8F8] rounded-lg"></div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="text-center py-4 mt-4 bg-[#F8F8F8] rounded-lg">
                        <p className="text-[#888888] mb-2">Coming soon</p>
                        <p className="text-xs text-[#888888]">More style customization options will be available in future updates</p>
                      </div>
                      
                      <div className="mt-8 flex justify-between">
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => setActiveTab("appearance")}
                        >
                          Back
                        </Button>
                        <Button 
                          type="button" 
                          className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                          onClick={() => {
                            toast({
                              title: "Avatar complete!",
                              description: "Your fashion twin is ready for virtual try-ons",
                            });
                          }}
                        >
                          Complete Setup
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}