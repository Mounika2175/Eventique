import { useState } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { 
  User,
  Settings,
  Key,
  ShoppingBag,
  Heart,
  Clock,
  CreditCard
} from "lucide-react";

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  country: z.string().optional(),
});

const securitySchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type SecurityFormValues = z.infer<typeof securitySchema>;

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      country: "",
    },
  });
  
  const securityForm = useForm<SecurityFormValues>({
    resolver: zodResolver(securitySchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  const onProfileSubmit = (data: ProfileFormValues) => {
    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully.",
    });
  };

  const onSecuritySubmit = (data: SecurityFormValues) => {
    toast({
      title: "Password changed",
      description: "Your password has been changed successfully.",
    });
    securityForm.reset();
  };

  const getInitials = () => {
    if (!user) return "U";
    
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`;
    }
    
    return user.username.slice(0, 2).toUpperCase();
  };

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Your Profile</title>
      </Helmet>
      
      <div className="py-10 bg-[#F8F8F8] min-h-screen">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
              Your Profile
            </h1>
            <p className="max-w-2xl mx-auto text-[#4A4A4A]">
              Manage your personal information and account preferences.
            </p>
          </motion.div>
          
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <motion.div 
              className="md:w-1/4"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="bg-white rounded-2xl shadow-md p-6">
                <div className="flex flex-col items-center mb-6">
                  <Avatar className="h-24 w-24 border-4 border-[#E8C8A9]">
                    <AvatarImage 
                      src={`https://ui-avatars.com/api/?name=${user?.username}&background=E8C8A9&color=222222&size=128`} 
                      alt={user?.username} 
                    />
                    <AvatarFallback className="bg-[#E8C8A9] text-[#222222] text-2xl">{getInitials()}</AvatarFallback>
                  </Avatar>
                  <h2 className="mt-4 font-medium text-xl text-[#222222]">{user?.username}</h2>
                  <p className="text-[#888888]">{user?.email}</p>
                </div>
                
                <div className="space-y-1">
                  <button 
                    className={`w-full flex items-center p-3 rounded-lg text-left ${activeTab === "profile" ? "bg-[#E8C8A9] bg-opacity-20 text-[#222222]" : "text-[#4A4A4A] hover:bg-[#F8F8F8]"}`}
                    onClick={() => setActiveTab("profile")}
                  >
                    <User className="mr-3 h-5 w-5" />
                    <span>Personal Information</span>
                  </button>
                  
                  <button 
                    className={`w-full flex items-center p-3 rounded-lg text-left ${activeTab === "security" ? "bg-[#E8C8A9] bg-opacity-20 text-[#222222]" : "text-[#4A4A4A] hover:bg-[#F8F8F8]"}`}
                    onClick={() => setActiveTab("security")}
                  >
                    <Key className="mr-3 h-5 w-5" />
                    <span>Security</span>
                  </button>
                  
                  <button 
                    className={`w-full flex items-center p-3 rounded-lg text-left ${activeTab === "orders" ? "bg-[#E8C8A9] bg-opacity-20 text-[#222222]" : "text-[#4A4A4A] hover:bg-[#F8F8F8]"}`}
                    onClick={() => setActiveTab("orders")}
                  >
                    <ShoppingBag className="mr-3 h-5 w-5" />
                    <span>Orders & Rentals</span>
                  </button>
                  
                  <button 
                    className={`w-full flex items-center p-3 rounded-lg text-left ${activeTab === "favorites" ? "bg-[#E8C8A9] bg-opacity-20 text-[#222222]" : "text-[#4A4A4A] hover:bg-[#F8F8F8]"}`}
                    onClick={() => setActiveTab("favorites")}
                  >
                    <Heart className="mr-3 h-5 w-5" />
                    <span>Saved Items</span>
                  </button>
                  
                  <button 
                    className={`w-full flex items-center p-3 rounded-lg text-left ${activeTab === "payments" ? "bg-[#E8C8A9] bg-opacity-20 text-[#222222]" : "text-[#4A4A4A] hover:bg-[#F8F8F8]"}`}
                    onClick={() => setActiveTab("payments")}
                  >
                    <CreditCard className="mr-3 h-5 w-5" />
                    <span>Payment Methods</span>
                  </button>
                </div>
              </div>
            </motion.div>
            
            {/* Main Content */}
            <motion.div 
              className="md:w-3/4"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="bg-white rounded-2xl shadow-md p-6">
                {activeTab === "profile" && (
                  <div>
                    <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222] mb-6">
                      Personal Information
                    </h2>
                    
                    <Form {...profileForm}>
                      <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={profileForm.control}
                            name="firstName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>First Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your first name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="lastName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Last Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your last name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={profileForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={profileForm.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number (optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your phone number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <h3 className="text-lg font-medium text-[#222222] mt-8 mb-4">Shipping Address</h3>
                        
                        <FormField
                          control={profileForm.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Street Address</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={profileForm.control}
                            name="city"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>City</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your city" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="state"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>State/Province</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your state" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={profileForm.control}
                            name="zipCode"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ZIP/Postal Code</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your ZIP code" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="country"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Country</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your country" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="flex justify-end">
                          <Button
                            type="submit"
                            className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                          >
                            Save Changes
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                )}
                
                {activeTab === "security" && (
                  <div>
                    <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222] mb-6">
                      Security
                    </h2>
                    
                    <Form {...securityForm}>
                      <form onSubmit={securityForm.handleSubmit(onSecuritySubmit)} className="space-y-6">
                        <FormField
                          control={securityForm.control}
                          name="currentPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Current Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Enter your current password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={securityForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>New Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Enter your new password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={securityForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm New Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Confirm your new password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end">
                          <Button
                            type="submit"
                            className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                          >
                            Change Password
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                )}
                
                {activeTab === "orders" && (
                  <div>
                    <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222] mb-6">
                      Orders & Rentals
                    </h2>
                    
                    <div className="text-center py-16">
                      <ShoppingBag className="h-16 w-16 text-[#E1E1E1] mx-auto mb-4" />
                      <h3 className="text-xl font-medium text-[#222222] mb-2">No orders yet</h3>
                      <p className="text-[#888888] mb-6">You haven't made any rentals or purchases yet</p>
                      <Button 
                        className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                        onClick={() => window.location.href = "/rentals"}
                      >
                        Browse Rentals
                      </Button>
                    </div>
                  </div>
                )}
                
                {activeTab === "favorites" && (
                  <div>
                    <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222] mb-6">
                      Saved Items
                    </h2>
                    
                    <div className="text-center py-16">
                      <Heart className="h-16 w-16 text-[#E1E1E1] mx-auto mb-4" />
                      <h3 className="text-xl font-medium text-[#222222] mb-2">No saved items</h3>
                      <p className="text-[#888888] mb-6">Items you save will appear here</p>
                      <Button 
                        className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                        onClick={() => window.location.href = "/rentals"}
                      >
                        Browse Rentals
                      </Button>
                    </div>
                  </div>
                )}
                
                {activeTab === "payments" && (
                  <div>
                    <h2 className="font-[Playfair_Display] text-2xl font-semibold text-[#222222] mb-6">
                      Payment Methods
                    </h2>
                    
                    <div className="text-center py-16">
                      <CreditCard className="h-16 w-16 text-[#E1E1E1] mx-auto mb-4" />
                      <h3 className="text-xl font-medium text-[#222222] mb-2">No payment methods</h3>
                      <p className="text-[#888888] mb-6">You haven't added any payment methods yet</p>
                      <Button 
                        className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                      >
                        Add Payment Method
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}