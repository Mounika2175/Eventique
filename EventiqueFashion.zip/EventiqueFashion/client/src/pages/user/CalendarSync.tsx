import { useState } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar as CalendarIcon, Check, Clock, AlertCircle } from "lucide-react";
import { calendarEvents } from "@/lib/data";

// Create a Google icon component since it's not part of Lucide
const GoogleIcon = (props: any) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 48 48" 
    width="1em" 
    height="1em" 
    {...props}
  >
    <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z" />
    <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z" />
    <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z" />
    <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z" />
  </svg>
);

const AppleIcon = (props: any) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 384 512" 
    width="1em" 
    height="1em" 
    {...props}
  >
    <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z" />
  </svg>
);

const OutlookIcon = (props: any) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 48 48" 
    width="1em" 
    height="1em" 
    {...props}
  >
    <path fill="#0078d4" d="M44,18.309V10c0-1.336-1.014-2.5-2.25-2.5H26.656c-4,0-7.5,3.082-7.5,7v6.809A3.839,3.839,0,0,0,18,24.117V39.4A2.673,2.673,0,0,0,20.75,42H41.25C43.137,42,44,40.234,44,38.484V24.117A3.839,3.839,0,0,0,44,18.309Z" />
    <path fill="#0078d4" d="M20,21.383V10c0-3.918,3.178-7,7-7H25.027A3.946,3.946,0,0,0,21,6.971V24h1C21.449,23.109,21,22.254,21,21.383Z" />
    <path fill="#0078d4" d="M6,18.309V10c0-1.336,1.014-2.5,2.25-2.5H11c-3,0-4.5,1.5-4.5,4.5v6.809A3.839,3.839,0,0,0,7,21.617V38.484C7,40.234,6.137,42,4.25,42H8.75C6.863,42,6,40.234,6,38.484V21.617A3.839,3.839,0,0,0,6,18.309Z" />
    <rect width="12" height="12" x="6" y="24" fill="#0078d4" />
    <path fill="#fff" d="M18,15a3,3,0,0,0-3-3H9a3,3,0,0,0-3,3v6a3,3,0,0,0,3,3h6a3,3,0,0,0,3-3ZM12,22.5,9.75,15h1.5L12,16.563,12.75,15h1.5Z" />
  </svg>
);

export default function CalendarSync() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [connectStep, setConnectStep] = useState(1);
  const [selectedCalendar, setSelectedCalendar] = useState<string | null>(null);
  const [preferences, setPreferences] = useState({
    syncEvents: true,
    getOutfitSuggestions: true,
    notifyBeforeEvents: true,
    syncFrequency: "daily"
  });

  const handleCalendarSelect = (provider: string) => {
    setSelectedCalendar(provider);
    setConnectStep(2);
  };

  const handleConnect = () => {
    toast({
      title: "Calendar connected",
      description: "Your calendar has been successfully synced with EVENTIQUE",
    });
    setConnectStep(3);
  };

  const togglePreference = (key: keyof typeof preferences) => {
    setPreferences(prev => ({
      ...prev,
      [key]: typeof prev[key] === 'boolean' ? !prev[key] : prev[key]
    }));
  };

  const calendarDays = Array.from({ length: 20 }, (_, i) => i + 1);

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Calendar Integration</title>
      </Helmet>
      
      <div className="py-10 bg-[#F8F8F8] min-h-screen">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
              Calendar Integration
            </h1>
            <p className="max-w-2xl mx-auto text-[#4A4A4A]">
              Sync your calendar to get personalized outfit recommendations for all your upcoming events.
            </p>
          </motion.div>
          
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Setup/Instructions */}
            <motion.div 
              className="lg:w-1/2"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-6">
                  Connect Your Calendar
                </h2>
                
                {connectStep === 1 && (
                  <div className="space-y-6">
                    <p className="text-[#4A4A4A] mb-6">
                      Choose your calendar provider to get started. We'll sync your events and provide outfit recommendations based on event type, formality, and weather.
                    </p>
                    
                    <div className="space-y-4">
                      <button 
                        className="w-full flex items-center p-4 border border-[#E1E1E1] rounded-lg hover:border-[#E8C8A9] hover:bg-[#E8C8A9] hover:bg-opacity-5 transition-all"
                        onClick={() => handleCalendarSelect("google")}
                      >
                        <div className="w-10 h-10 bg-white rounded-full shadow-sm flex items-center justify-center mr-4">
                          <GoogleIcon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 text-left">
                          <h3 className="font-medium text-[#222222]">Google Calendar</h3>
                          <p className="text-xs text-[#888888]">Connect with your Google account</p>
                        </div>
                      </button>
                      
                      <button 
                        className="w-full flex items-center p-4 border border-[#E1E1E1] rounded-lg hover:border-[#E8C8A9] hover:bg-[#E8C8A9] hover:bg-opacity-5 transition-all"
                        onClick={() => handleCalendarSelect("apple")}
                      >
                        <div className="w-10 h-10 bg-white rounded-full shadow-sm flex items-center justify-center mr-4">
                          <AppleIcon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 text-left">
                          <h3 className="font-medium text-[#222222]">Apple Calendar</h3>
                          <p className="text-xs text-[#888888]">Connect with your Apple ID</p>
                        </div>
                      </button>
                      
                      <button 
                        className="w-full flex items-center p-4 border border-[#E1E1E1] rounded-lg hover:border-[#E8C8A9] hover:bg-[#E8C8A9] hover:bg-opacity-5 transition-all"
                        onClick={() => handleCalendarSelect("outlook")}
                      >
                        <div className="w-10 h-10 bg-white rounded-full shadow-sm flex items-center justify-center mr-4">
                          <OutlookIcon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 text-left">
                          <h3 className="font-medium text-[#222222]">Outlook Calendar</h3>
                          <p className="text-xs text-[#888888]">Connect with your Microsoft account</p>
                        </div>
                      </button>
                    </div>
                    
                    <div className="bg-[#F8F8F8] p-4 rounded-lg">
                      <h3 className="flex items-center text-[#222222] font-medium mb-2">
                        <AlertCircle className="h-4 w-4 mr-2" />
                        Privacy Information
                      </h3>
                      <p className="text-xs text-[#888888]">
                        EVENTIQUE only accesses your calendar event titles, dates, and locations to provide outfit recommendations. We never store or share your personal calendar data with third parties.
                      </p>
                    </div>
                  </div>
                )}
                
                {connectStep === 2 && (
                  <div className="space-y-6">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-white rounded-full shadow-sm flex items-center justify-center mr-4 border border-[#E1E1E1]">
                        {selectedCalendar === "google" && <GoogleIcon className="h-5 w-5" />}
                        {selectedCalendar === "apple" && <AppleIcon className="h-5 w-5" />}
                        {selectedCalendar === "outlook" && <OutlookIcon className="h-5 w-5" />}
                      </div>
                      <div>
                        <h3 className="font-medium text-[#222222]">
                          {selectedCalendar === "google" ? "Google Calendar" : 
                           selectedCalendar === "apple" ? "Apple Calendar" : 
                           "Outlook Calendar"}
                        </h3>
                        <p className="text-xs text-[#888888]">Ready to connect</p>
                      </div>
                    </div>
                    
                    <div className="border border-[#E1E1E1] rounded-lg p-6">
                      <h3 className="font-medium text-[#222222] mb-4">Account Information</h3>
                      
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input id="email" type="email" placeholder="your@email.com" defaultValue={user?.email} />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="password">Password</Label>
                          <Input id="password" type="password" placeholder="••••••••" />
                          <p className="text-xs text-[#888888]">
                            Note: In a real app, we would use OAuth instead of requesting passwords directly.
                          </p>
                        </div>
                      </div>
                      
                      <div className="mt-6 flex justify-between">
                        <Button 
                          variant="outline" 
                          onClick={() => setConnectStep(1)}
                        >
                          Back
                        </Button>
                        <Button 
                          className="bg-[#222222] hover:bg-[#2A2A2A] text-white"
                          onClick={handleConnect}
                        >
                          Connect
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                
                {connectStep === 3 && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-center p-6 bg-[#E8C8A9] bg-opacity-20 rounded-lg">
                      <div className="w-12 h-12 bg-[#E8C8A9] rounded-full flex items-center justify-center mr-4">
                        <Check className="h-6 w-6 text-[#222222]" />
                      </div>
                      <div>
                        <h3 className="font-medium text-[#222222]">Calendar Connected!</h3>
                        <p className="text-sm text-[#888888]">
                          {selectedCalendar === "google" ? "Google Calendar" : 
                           selectedCalendar === "apple" ? "Apple Calendar" : 
                           "Outlook Calendar"} has been successfully linked
                        </p>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-medium text-[#222222] mt-6">Sync Preferences</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[#222222] font-medium">Sync Events</p>
                          <p className="text-xs text-[#888888]">Keep events synchronized with EVENTIQUE</p>
                        </div>
                        <Switch 
                          checked={preferences.syncEvents} 
                          onCheckedChange={() => togglePreference("syncEvents")} 
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[#222222] font-medium">Get Outfit Suggestions</p>
                          <p className="text-xs text-[#888888]">Receive personalized outfit recommendations for events</p>
                        </div>
                        <Switch 
                          checked={preferences.getOutfitSuggestions} 
                          onCheckedChange={() => togglePreference("getOutfitSuggestions")} 
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[#222222] font-medium">Event Notifications</p>
                          <p className="text-xs text-[#888888]">Get notified about upcoming events and outfit suggestions</p>
                        </div>
                        <Switch 
                          checked={preferences.notifyBeforeEvents} 
                          onCheckedChange={() => togglePreference("notifyBeforeEvents")} 
                        />
                      </div>
                      
                      <div className="pt-2">
                        <Label className="mb-2 block">Sync Frequency</Label>
                        <select 
                          className="w-full border border-[#E1E1E1] rounded-md p-2"
                          value={preferences.syncFrequency}
                          onChange={(e) => setPreferences({...preferences, syncFrequency: e.target.value})}
                        >
                          <option value="realtime">Real-time</option>
                          <option value="hourly">Hourly</option>
                          <option value="daily">Daily</option>
                          <option value="manual">Manual only</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <Button 
                        className="w-full bg-[#222222] hover:bg-[#2A2A2A] text-white"
                        onClick={() => {
                          toast({
                            title: "Preferences saved",
                            description: "Your calendar sync preferences have been updated",
                          });
                        }}
                      >
                        Save Preferences
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
            
            {/* Calendar Preview */}
            <motion.div 
              className="lg:w-1/2"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-6">
                  Your Events
                </h2>
                
                <Tabs defaultValue="month">
                  <TabsList className="grid w-full grid-cols-3 mb-6">
                    <TabsTrigger value="month">Month</TabsTrigger>
                    <TabsTrigger value="week">Week</TabsTrigger>
                    <TabsTrigger value="day">Day</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="month">
                    <div className="mb-6">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="font-medium text-[#4A4A4A]">October 2023</h3>
                        <div className="flex space-x-2">
                          <button className="w-8 h-8 rounded-full bg-[#F8F8F8] flex items-center justify-center hover:bg-[#E1E1E1] transition-colors">
                            <svg 
                              xmlns="http://www.w3.org/2000/svg" 
                              className="h-4 w-4 text-[#888888]" 
                              fill="none" 
                              viewBox="0 0 24 24" 
                              stroke="currentColor"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                            </svg>
                          </button>
                          <button className="w-8 h-8 rounded-full bg-[#F8F8F8] flex items-center justify-center hover:bg-[#E1E1E1] transition-colors">
                            <svg 
                              xmlns="http://www.w3.org/2000/svg" 
                              className="h-4 w-4 text-[#888888]" 
                              fill="none" 
                              viewBox="0 0 24 24" 
                              stroke="currentColor"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-7 gap-1 mb-2">
                        {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map((day, index) => (
                          <div key={index} className="text-[#888888] text-xs text-center">{day}</div>
                        ))}
                      </div>
                      
                      <div className="grid grid-cols-7 gap-1">
                        {calendarDays.map((day, index) => {
                          let className = "aspect-square flex items-center justify-center rounded-full transition-all duration-200 text-sm";
                          
                          // Add special styling for specific days
                          if (day === 11) {
                            className += " bg-[#D64045] text-white";
                          } else if (day === 13) {
                            className += " bg-[#E8C8A9] text-[#222222]";
                          } else if (day === 18) {
                            className += " bg-[#E1E1E1]";
                          } else {
                            className += " hover:bg-[#E8C8A9] hover:text-[#222222]";
                          }
                          
                          return (
                            <div key={index} className={className}>
                              {day}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="week">
                    <div className="text-center py-6">
                      <CalendarIcon className="h-12 w-12 text-[#E1E1E1] mx-auto mb-4" />
                      <p className="text-[#888888]">Week view will be available after syncing your calendar</p>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="day">
                    <div className="text-center py-6">
                      <CalendarIcon className="h-12 w-12 text-[#E1E1E1] mx-auto mb-4" />
                      <p className="text-[#888888]">Day view will be available after syncing your calendar</p>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="mt-6 space-y-4">
                  <h3 className="font-medium text-[#222222]">Upcoming Events</h3>
                  
                  {connectStep < 3 ? (
                    <div className="text-center py-8 border border-dashed border-[#E1E1E1] rounded-lg">
                      <CalendarIcon className="h-12 w-12 text-[#E1E1E1] mx-auto mb-4" />
                      <p className="text-[#888888] mb-2">Connect your calendar to see events</p>
                      <p className="text-xs text-[#888888]">Your events will appear here after syncing</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {calendarEvents.map((event, index) => (
                        <div 
                          key={index} 
                          className={`border-l-4 ${
                            event.eventType === 'formal' ? 'border-[#D64045] bg-[#D64045] bg-opacity-5' : 
                            event.eventType === 'casual' ? 'border-[#E8C8A9] bg-[#E8C8A9] bg-opacity-5' : 
                            'border-[#4A4A4A] bg-[#4A4A4A] bg-opacity-5'
                          } p-4 rounded-r-lg`}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h5 className="font-medium text-[#222222]">{event.title}</h5>
                              <p className="text-sm text-[#888888]">
                                {new Date(event.date).toLocaleDateString('en-US', { 
                                  month: 'short', 
                                  day: 'numeric', 
                                  hour: 'numeric', 
                                  minute: '2-digit' 
                                })}
                              </p>
                            </div>
                            <span className={`text-xs ${
                              event.eventType === 'formal' ? 'bg-[#D64045] text-white' : 
                              event.eventType === 'casual' ? 'bg-[#E8C8A9] text-[#222222]' : 
                              'bg-[#4A4A4A] text-white'
                            } px-2 py-1 rounded-full`}>
                              {event.eventType.charAt(0).toUpperCase() + event.eventType.slice(1)}
                            </span>
                          </div>
                          <div className="mt-3 flex items-center">
                            <div className="w-12 h-16 bg-[#E1E1E1] rounded-md overflow-hidden">
                              <img 
                                src={event.outfitSuggestion.imageUrl} 
                                alt="Outfit suggestion"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium text-[#222222]">Recommended Outfit</p>
                              <p className="text-xs text-[#888888]">{event.outfitSuggestion.name}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}