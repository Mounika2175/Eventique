import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calendar, TrendingUp, Shirt, ShoppingBag, Users } from "lucide-react";
import { calendarEvents } from "@/lib/data";

export default function UserHome() {
  const { user } = useAuth();
  
  // For a real app, we would fetch these from the API
  const { data: upcomingEvents } = useQuery({
    queryKey: ['/api/events/user', user?.id],
    queryFn: async () => calendarEvents, // Using mock data for now
    enabled: !!user?.id
  });

  // Feature cards for the dashboard
  const features = [
    {
      title: "Create Your Avatar",
      description: "Set up your virtual fashion twin for accurate try-ons",
      icon: <Users className="h-12 w-12 text-[#E8C8A9]" />,
      path: "/avatar",
      color: "bg-[#222222]",
      buttonText: "Create Avatar"
    },
    {
      title: "Connect Calendar",
      description: "Sync your calendar for event-based outfit suggestions",
      icon: <Calendar className="h-12 w-12 text-[#222222]" />,
      path: "/calendar",
      color: "bg-[#E8C8A9]",
      buttonText: "Connect Now"
    },
    {
      title: "Explore Seasonal Trends",
      description: "Discover the latest fashion trends for the current season",
      icon: <TrendingUp className="h-12 w-12 text-white" />,
      path: "/trends",
      color: "bg-[#4A4A4A]",
      buttonText: "View Trends"
    },
    {
      title: "Browse Rentals",
      description: "Find premium fashion pieces for your upcoming events",
      icon: <ShoppingBag className="h-12 w-12 text-[#222222]" />,
      path: "/rentals",
      color: "bg-[#E8C8A9]",
      buttonText: "See Rentals"
    }
  ];

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Your Fashion Dashboard</title>
      </Helmet>
      
      <div className="py-10 md:py-16 bg-[#F8F8F8]">
        <div className="container mx-auto px-4">
          {/* Welcome Section */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222]">
                Welcome, {user?.firstName || user?.username}
              </h1>
              <p className="text-[#888888] mt-2">
                Your personalized fashion dashboard - explore new styles, plan your outfits, and manage your rentals
              </p>
            </div>
            <div className="hidden md:block">
              <Link href="/profile">
                <a className="inline-block font-[Montserrat] px-6 py-2 rounded-full text-white bg-[#222222] hover:bg-[#2A2A2A] transition-colors">
                  Edit Profile
                </a>
              </Link>
            </div>
          </div>
          
          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className={`${feature.color} rounded-2xl p-6 shadow-md text-white`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <div className="mb-4">
                  {feature.icon}
                </div>
                <h3 className="font-[Playfair_Display] text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm opacity-80 mb-4">{feature.description}</p>
                <Link href={feature.path}>
                  <a className="inline-block bg-white/20 hover:bg-white/30 px-4 py-2 rounded-full text-sm font-medium transition-colors">
                    {feature.buttonText}
                  </a>
                </Link>
              </motion.div>
            ))}
          </div>
          
          {/* Upcoming Events */}
          <div className="bg-white rounded-2xl shadow-md p-6 mb-12">
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-[Playfair_Display] text-2xl font-bold text-[#222222]">Upcoming Events</h2>
              <Link href="/calendar">
                <a className="text-[#222222] hover:text-[#E8C8A9] text-sm font-medium">
                  View Calendar →
                </a>
              </Link>
            </div>
            
            {upcomingEvents && upcomingEvents.length > 0 ? (
              <div className="space-y-4">
                {upcomingEvents.map((event, index) => (
                  <div 
                    key={index} 
                    className={`border-l-4 ${
                      event.eventType === 'formal' ? 'border-[#D64045] bg-[#D64045] bg-opacity-5' : 
                      event.eventType === 'casual' ? 'border-[#E8C8A9] bg-[#E8C8A9] bg-opacity-5' : 
                      'border-[#4A4A4A] bg-[#4A4A4A] bg-opacity-5'
                    } p-4 rounded-r-lg`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="font-medium text-[#222222]">{event.title}</h5>
                        <p className="text-sm text-[#888888]">
                          {new Date(event.date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            hour: 'numeric', 
                            minute: '2-digit' 
                          })}
                        </p>
                      </div>
                      <span className={`text-xs ${
                        event.eventType === 'formal' ? 'bg-[#D64045] text-white' : 
                        event.eventType === 'casual' ? 'bg-[#E8C8A9] text-[#222222]' : 
                        'bg-[#4A4A4A] text-white'
                      } px-2 py-1 rounded-full`}>
                        {event.eventType.charAt(0).toUpperCase() + event.eventType.slice(1)}
                      </span>
                    </div>
                    <div className="mt-3 flex items-center">
                      <div className="w-12 h-16 bg-[#E1E1E1] rounded-md overflow-hidden">
                        <img 
                          src={event.outfitSuggestion.imageUrl} 
                          alt="Outfit suggestion"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-[#222222]">Recommended Outfit</p>
                        <p className="text-xs text-[#888888]">{event.outfitSuggestion.name}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-[#E1E1E1] mx-auto mb-4" />
                <p className="text-[#888888] mb-2">No upcoming events</p>
                <p className="text-sm text-[#888888] mb-4">Connect your calendar to get outfit recommendations</p>
                <Link href="/calendar">
                  <a className="inline-block font-[Montserrat] px-5 py-2 rounded-full bg-[#222222] text-white text-sm hover:bg-[#2A2A2A] transition-colors">
                    Connect Calendar
                  </a>
                </Link>
              </div>
            )}
          </div>
          
          {/* Style Analysis */}
          <div className="bg-[#222222] text-white rounded-2xl shadow-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-[Playfair_Display] text-2xl font-bold">Your Style Analysis</h2>
              <Link href="/style-analysis">
                <a className="text-[#E8C8A9] hover:text-white text-sm font-medium">
                  View Full Analysis →
                </a>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-[#2A2A2A] rounded-xl p-4">
                <h3 className="text-sm text-[#E1E1E1] mb-2">Primary Style</h3>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-md bg-[#E8C8A9] text-[#222222] flex items-center justify-center mr-3">
                    <Shirt className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-medium">Modern Minimal</p>
                    <div className="w-full bg-[#4A4A4A] h-1 rounded-full mt-1">
                      <div className="bg-[#E8C8A9] h-1 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-[#2A2A2A] rounded-xl p-4">
                <h3 className="text-sm text-[#E1E1E1] mb-2">Color Preferences</h3>
                <div className="flex flex-wrap gap-2">
                  <div className="w-6 h-6 rounded-full bg-[#F8F8F8] ring-2 ring-[#E8C8A9]"></div>
                  <div className="w-6 h-6 rounded-full bg-[#4A4A4A]"></div>
                  <div className="w-6 h-6 rounded-full bg-blue-700"></div>
                  <div className="w-6 h-6 rounded-full bg-emerald-700"></div>
                </div>
              </div>
              
              <div className="bg-[#2A2A2A] rounded-xl p-4">
                <h3 className="text-sm text-[#E1E1E1] mb-2">Top Categories</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Business Casual</span>
                    <span className="text-xs text-[#E8C8A9]">74%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Evening Wear</span>
                    <span className="text-xs text-[#E8C8A9]">65%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}