import { Link } from "wouter";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <div className="relative h-screen">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')"
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[rgba(34,34,34,0.9)] to-[rgba(34,34,34,0.5)]"></div>
      </div>
      
      <div className="relative container mx-auto px-4 h-full flex flex-col justify-center">
        <motion.div 
          className="max-w-3xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="font-[Playfair_Display] text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            Redefine Your Style With AI-Powered Fashion
          </h1>
          <p className="text-lg md:text-xl text-[#F8F8F8] mb-8">
            Personalized outfit recommendations, virtual try-ons, and fashion rentals tailored to your events and preferences
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link href="/try-on">
                <a className="inline-block text-center w-full sm:w-auto font-[Montserrat] px-8 py-3 rounded-full bg-[#E8C8A9] text-[#222222] text-lg font-semibold hover:bg-opacity-90 transition-all">
                  Create Your Avatar
                </a>
              </Link>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link href="/features">
                <a className="inline-block text-center w-full sm:w-auto font-[Montserrat] px-8 py-3 rounded-full border-2 border-white text-white text-lg font-semibold hover:bg-white hover:bg-opacity-10 transition-all">
                  Explore Features
                </a>
              </Link>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
