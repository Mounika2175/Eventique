import { Link } from "wouter";
import { motion } from "framer-motion";

const features = [
  {
    icon: "tshirt",
    title: "Virtual Try-On System",
    description: "Create and customize your digital avatar to visualize outfits before making decisions.",
    link: "/try-on"
  },
  {
    icon: "calendar-alt",
    title: "Event-Based Recommendations",
    description: "Sync with your calendars and receive AI-driven outfit suggestions for each event type.",
    link: "/calendar"
  },
  {
    icon: "cloud-sun",
    title: "Seasonal Fashion Insights",
    description: "Get weather-integrated fashion recommendations that keep you stylish in any season.",
    link: "/seasonal"
  },
  {
    icon: "shopping-bag",
    title: "Fashion Rentals",
    description: "Rent instead of buying with our convenient fashion rental system including payment and returns.",
    link: "/rentals"
  },
  {
    icon: "brain",
    title: "AI-Powered Styling",
    description: "Machine learning personalization that improves recommendations based on your feedback.",
    link: "/ai-styling"
  },
  {
    icon: "user-circle",
    title: "Profile Management",
    description: "Store your preferences, customize avatars, and manage your fashion profile seamlessly.",
    link: "/profile"
  }
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { y: 0, opacity: 1, transition: { duration: 0.5 } }
};

export default function FeaturesOverview() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
            Revolutionize Your Fashion Experience
          </h2>
          <p className="max-w-2xl mx-auto text-[#888888]">
            EVENTIQUE combines AI technology with fashion expertise to create a personalized styling experience that adapts to your preferences, events, and seasonal trends.
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
        >
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              className="bg-[#F8F8F8] rounded-2xl p-8 transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
              variants={item}
            >
              <div className="bg-[#E8C8A9] bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-[#E8C8A9]"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  {feature.icon === "tshirt" && (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 13h10l2-9H5l2 9zm0 0v6h10v-6" />
                  )}
                  {feature.icon === "calendar-alt" && (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  )}
                  {feature.icon === "cloud-sun" && (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
                  )}
                  {feature.icon === "shopping-bag" && (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                  )}
                  {feature.icon === "brain" && (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" />
                  )}
                  {feature.icon === "user-circle" && (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  )}
                </svg>
              </div>
              <h3 className="font-[Playfair_Display] text-xl font-semibold text-[#222222] mb-3">
                {feature.title}
              </h3>
              <p className="text-[#4A4A4A] mb-4">
                {feature.description}
              </p>
              <Link href={feature.link}>
                <a className="inline-flex items-center font-medium text-[#222222] hover:text-[#888888] transition-colors">
                  Learn more 
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-4 w-4 ml-2" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
