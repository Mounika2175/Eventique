import { Link } from "wouter";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface RentalItem {
  id: number;
  name: string;
  duration: string;
  price: number;
  rating: number;
  reviews: number;
  imageUrl: string;
  badge?: {
    text: string;
    type: 'designer' | 'available' | 'limited' | 'premium';
  };
}

export default function FashionRentals() {
  // Fetch fashion rental items
  const { data: rentalItems, isLoading } = useQuery<RentalItem[]>({
    queryKey: ['/api/fashion-items'],
    staleTime: 60000, // 1 minute
  });

  // Use only the first 4 items for display
  const displayItems = rentalItems?.slice(0, 4) || [];

  const getColorForBadge = (type: string) => {
    switch (type) {
      case 'designer': return 'bg-[#222222] text-white';
      case 'available': return 'bg-[#2E8B57] text-white';
      case 'limited': return 'bg-[#FF6B6B] text-white';
      case 'premium': return 'bg-[#222222] text-white';
      default: return 'bg-[#888888] text-white';
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1, transition: { duration: 0.5 } }
  };

  // Generate placeholder items if data is loading
  const placeholderItems = Array(4).fill(null).map((_, index) => ({
    id: index,
    name: "Loading...",
    duration: "Loading...",
    price: 0,
    rating: 0,
    reviews: 0,
    imageUrl: "",
  }));

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
            Fashion Rentals
          </h2>
          <p className="max-w-2xl mx-auto text-[#4A4A4A]">
            Why buy when you can rent? Access premium fashion pieces for special events without the lifetime commitment.
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.1 }}
        >
          {isLoading ? (
            // Render placeholders while loading
            placeholderItems.map((item, index) => (
              <motion.div 
                key={index} 
                className="group relative animate-pulse"
                variants={item}
              >
                <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-gray-200"></div>
                <div className="mt-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                </div>
              </motion.div>
            ))
          ) : (
            // Render actual fashion items
            displayItems.map((rentalItem, index) => (
              <motion.div 
                key={index} 
                className="group relative"
                variants={item}
              >
                <div className="relative aspect-[2/3] rounded-xl overflow-hidden">
                  <img 
                    src={rentalItem.imageUrl || `https://images.unsplash.com/photo-1525450824786-227cbef70703?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80`} 
                    alt={rentalItem.name} 
                    className="w-full h-full object-cover" 
                  />
                  {rentalItem.badge && (
                    <div className={`absolute top-4 left-4 ${getColorForBadge(rentalItem.badge.type)} text-xs px-2 py-1 rounded`}>
                      {rentalItem.badge.text}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-70 transition-opacity"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform">
                    <Link href={`/rentals/${rentalItem.id}`}>
                      <a className="block w-full bg-[#E8C8A9] text-[#222222] text-center py-2 rounded-md font-medium">
                        Quick View
                      </a>
                    </Link>
                  </div>
                </div>
                
                <div className="mt-4">
                  <h3 className="font-medium text-[#222222]">{rentalItem.name}</h3>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-[#888888]">{rentalItem.duration || '3-day rental'}</p>
                    <p className="font-semibold text-[#222222]">${(rentalItem.price / 100).toFixed(2)}</p>
                  </div>
                  <div className="flex items-center mt-2">
                    <div className="flex">
                      {Array(5).fill(null).map((_, i) => (
                        <svg 
                          key={i}
                          xmlns="http://www.w3.org/2000/svg" 
                          className={`h-3 w-3 ${i < Math.floor(rentalItem.rating) ? 'text-[#E8C8A9]' : (i === Math.floor(rentalItem.rating) && rentalItem.rating % 1 > 0 ? 'text-[#E8C8A9]' : 'text-[#E1E1E1]')}`}
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          {i < Math.floor(rentalItem.rating) ? (
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          ) : (
                            i === Math.floor(rentalItem.rating) && rentalItem.rating % 1 > 0 ? (
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            ) : (
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            )
                          )}
                        </svg>
                      ))}
                    </div>
                    <p className="text-xs text-[#888888] ml-1">({rentalItem.reviews || 0})</p>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </motion.div>
        
        <div className="mt-12 flex justify-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link href="/rentals">
              <a className="font-[Montserrat] px-8 py-3 rounded-full bg-[#222222] text-white text-center font-semibold hover:bg-[#2A2A2A] transition-all">
                Browse All Rentals
              </a>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
