import { Link } from "wouter";
import { motion } from "framer-motion";

const benefits = [
  "Precise body measurements and customization",
  "Realistic fabric rendering and movement",
  "Save and share your favorite looks"
];

export default function VirtualTryOn() {
  return (
    <section className="py-16 md:py-24 bg-[#222222] text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <motion.div 
            className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-12"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold mb-6">
              Create Your Digital Fashion Twin
            </h2>
            <p className="text-[#E1E1E1] mb-8">
              Our advanced 3D avatar technology allows you to create a precise digital representation of yourself. Try on hundreds of outfits virtually and see exactly how they'll look on your body type.
            </p>
            
            <div className="space-y-4 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[#E8C8A9] flex items-center justify-center mt-1">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-3 w-3 text-[#222222]" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="ml-4 text-[#E1E1E1]">{benefit}</p>
                </div>
              ))}
            </div>
            
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link href="/try-on">
                <a className="inline-block font-[Montserrat] px-8 py-3 rounded-full bg-[#E8C8A9] text-[#222222] text-center font-semibold hover:bg-opacity-90 transition-all">
                  Create Your Avatar
                </a>
              </Link>
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2 bg-gradient-to-br from-[#E8C8A9] to-[#f8eddf] rounded-2xl p-8"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="relative aspect-[3/4] rounded-xl overflow-hidden bg-[#222222] flex items-center justify-center">
              <div className="text-center p-6">
                <div className="w-24 h-24 mx-auto mb-4 rounded-full border-2 border-dashed border-[#E8C8A9] flex items-center justify-center">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-12 w-12 text-[#E8C8A9]" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <p className="text-[#E1E1E1] text-lg">Your 3D Avatar</p>
                <p className="text-[#888888] text-sm mt-2">This is where your interactive 3D model will appear</p>
              </div>
              
              <div className="absolute bottom-4 left-4 right-4 flex justify-center space-x-4">
                <button className="w-10 h-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center hover:bg-opacity-20 transition-colors">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-5 w-5 text-white" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                </button>
                <button className="w-10 h-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center hover:bg-opacity-20 transition-colors">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-5 w-5 text-white" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                </button>
                <button className="w-10 h-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center hover:bg-opacity-20 transition-colors">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-5 w-5 text-white" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </button>
              </div>
            </div>
            
            <div className="mt-6 grid grid-cols-4 gap-4">
              {['Tops', 'Bottoms', 'Shoes', 'Accessories'].map((item, index) => (
                <div key={index} className="bg-white bg-opacity-10 rounded-lg p-2 cursor-pointer hover:bg-opacity-20 transition-colors">
                  <div className="aspect-square rounded-md bg-[#222222] flex items-center justify-center">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-6 w-6 text-[#E8C8A9]" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      {index === 0 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 13h10l2-9H5l2 9zm0 0v6h10v-6" />}
                      {index === 1 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 6v12m0 0H5m4 0h6m2-12v12m0-12h4m-4 0H9" />}
                      {index === 2 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />}
                      {index === 3 && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-.553.894L15 19m0-9l-9-4.5v10.5l9 4.5V10z" />}
                    </svg>
                  </div>
                  <p className="text-xs text-center mt-1 text-white">{item}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
