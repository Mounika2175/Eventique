import { Link } from "wouter";
import { motion } from "framer-motion";

const benefits = [
  "Automatic event type detection",
  "Seamless calendar integration",
  "Outfit planning weeks in advance"
];

const calendarDays = Array.from({ length: 20 }, (_, i) => i + 1);

export default function CalendarIntegration() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row-reverse items-center">
          <motion.div 
            className="lg:w-1/2 mb-10 lg:mb-0 lg:pl-12"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-6">
              Outfit Recommendations for Every Event
            </h2>
            <p className="text-[#4A4A4A] mb-8">
              Sync your Google, Apple, or Outlook calendars with EVENTIQUE and receive personalized outfit recommendations for each event. Our AI analyzes event type, location, and formality to suggest the perfect look.
            </p>
            
            <div className="space-y-4 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[#E8C8A9] flex items-center justify-center mt-1">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-3 w-3 text-[#222222]" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="ml-4 text-[#4A4A4A]">{benefit}</p>
                </div>
              ))}
            </div>
            
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link href="/calendar-connect">
                <a className="inline-block font-[Montserrat] px-8 py-3 rounded-full bg-[#222222] text-white text-center font-semibold hover:bg-[#2A2A2A] transition-all">
                  Connect Your Calendar
                </a>
              </Link>
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2 bg-[#F8F8F8] rounded-2xl p-6 shadow-lg"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-[Playfair_Display] text-xl font-semibold text-[#222222]">Your Events</h3>
                <div className="flex space-x-2">
                  <button className="w-8 h-8 rounded-full bg-[#F8F8F8] flex items-center justify-center hover:bg-[#E1E1E1] transition-colors">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-4 w-4 text-[#888888]" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                  </button>
                  <button className="w-8 h-8 rounded-full bg-[#F8F8F8] flex items-center justify-center hover:bg-[#E1E1E1] transition-colors">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-4 w-4 text-[#888888]" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="mb-6">
                <div className="text-center mb-4">
                  <h4 className="font-medium text-[#4A4A4A]">October 2023</h4>
                </div>
                
                <div className="grid grid-cols-7 gap-1 mb-2">
                  {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map((day, index) => (
                    <div key={index} className="text-[#888888] text-xs text-center">{day}</div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-1">
                  {calendarDays.map((day, index) => {
                    let className = "aspect-square flex items-center justify-center rounded-full transition-all duration-200 text-sm";
                    
                    // Add special styling for specific days
                    if (day === 11) {
                      className += " bg-[#D64045] text-white";
                    } else if (day === 13) {
                      className += " bg-[#E8C8A9] text-[#222222]";
                    } else if (day === 18) {
                      className += " bg-[#E1E1E1]";
                    } else {
                      className += " hover:bg-[#E8C8A9] hover:text-[#222222]";
                    }
                    
                    return (
                      <div key={index} className={className}>
                        {day}
                      </div>
                    );
                  })}
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="border-l-4 border-[#D64045] bg-[#D64045] bg-opacity-5 p-3 rounded-r-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <h5 className="font-medium text-[#222222]">Business Meeting</h5>
                      <p className="text-sm text-[#888888]">Oct 11, 9:00 AM - 10:30 AM</p>
                    </div>
                    <span className="text-xs bg-[#D64045] text-white px-2 py-1 rounded-full">Formal</span>
                  </div>
                  <div className="mt-3 flex items-center">
                    <div className="w-12 h-16 bg-[#E1E1E1] rounded-md overflow-hidden">
                      <img 
                        src="https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80" 
                        alt="Outfit suggestion"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-[#222222]">Recommended Outfit</p>
                      <p className="text-xs text-[#888888]">Navy suit with white shirt</p>
                    </div>
                  </div>
                </div>
                
                <div className="border-l-4 border-[#E8C8A9] bg-[#E8C8A9] bg-opacity-5 p-3 rounded-r-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <h5 className="font-medium text-[#222222]">Dinner Party</h5>
                      <p className="text-sm text-[#888888]">Oct 13, 7:00 PM - 10:00 PM</p>
                    </div>
                    <span className="text-xs bg-[#E8C8A9] text-[#222222] px-2 py-1 rounded-full">Smart Casual</span>
                  </div>
                  <div className="mt-3 flex items-center">
                    <div className="w-12 h-16 bg-[#E1E1E1] rounded-md overflow-hidden">
                      <img 
                        src="https://images.unsplash.com/photo-1549062572-544a64fb0c56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80" 
                        alt="Outfit suggestion"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-[#222222]">Recommended Outfit</p>
                      <p className="text-xs text-[#888888]">Casual blazer with chinos</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
