import HeroSection from "./HeroSection";
import FeaturesOverview from "./FeaturesOverview";
import VirtualTryOn from "./VirtualTryOn";
import CalendarIntegration from "./CalendarIntegration";
import SeasonalTrends from "./SeasonalTrends";
import FashionRentals from "./FashionRentals";
import AIPersonalization from "./AIPersonalization";
import CTASection from "./CTASection";
import { Helmet } from "react-helmet";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function HomePage() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      setLocation('/dashboard');
    }
  }, [isAuthenticated, setLocation]);

  return (
    <>
      <Helmet>
        <title>EVENTIQUE - Virtual Fashion Platform</title>
        <meta name="description" content="Personalized outfit recommendations, virtual try-ons, and fashion rentals for every occasion" />
      </Helmet>
      <div>
        <HeroSection />
        <FeaturesOverview />
        <VirtualTryOn />
        <CalendarIntegration />
        <SeasonalTrends />
        <FashionRentals />
        <AIPersonalization />
        <CTASection />
      </div>
    </>
  );
}
