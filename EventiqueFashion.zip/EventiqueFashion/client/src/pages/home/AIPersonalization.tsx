import { Link } from "wouter";
import { motion } from "framer-motion";

const steps = [
  {
    number: 1,
    title: "Initial Style Quiz",
    description: "Begin with a quick assessment of your preferences and style profile."
  },
  {
    number: 2,
    title: "Usage Learning",
    description: "Our AI observes your interactions with recommendations and saved outfits."
  },
  {
    number: 3,
    title: "Feedback Integration",
    description: "Rate recommendations to actively train your personal style algorithm."
  },
  {
    number: 4,
    title: "Evolved Recommendations",
    description: "Experience increasingly personalized suggestions that evolve with your style."
  }
];

const likedItems = [
  "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&q=80",
  "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&q=80",
  "https://images.unsplash.com/photo-1543076447-215ad9ba6923?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&q=80",
  "https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&q=80"
];

export default function AIPersonalization() {
  return (
    <section className="py-16 md:py-24 bg-[#222222] text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <motion.div 
            className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-12"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold mb-6">
              AI-Powered Style Evolution
            </h2>
            <p className="text-[#E1E1E1] mb-8">
              Our advanced machine learning algorithms learn your preferences over time, creating increasingly accurate style suggestions tailored specifically to you.
            </p>
            
            <div className="space-y-6 mb-8">
              {steps.map((step, index) => (
                <motion.div 
                  key={index} 
                  className="flex"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#E8C8A9] flex items-center justify-center mr-4">
                    <span className="font-semibold text-[#222222]">{step.number}</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-white mb-1">{step.title}</h3>
                    <p className="text-[#888888]">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link href="/style-analysis">
                <a className="inline-block font-[Montserrat] px-8 py-3 rounded-full bg-[#E8C8A9] text-[#222222] text-center font-semibold hover:bg-opacity-90 transition-all">
                  Start Style Analysis
                </a>
              </Link>
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2 bg-[#2A2A2A] rounded-2xl p-6 shadow-lg"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="mb-6 flex justify-between items-center">
              <h3 className="font-[Playfair_Display] text-xl font-semibold text-white">Your Style Profile</h3>
              <span className="text-xs bg-[#E8C8A9] text-[#222222] px-3 py-1 rounded-full">AI-Enhanced</span>
            </div>
            
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <p className="text-[#E1E1E1] text-sm">Style Preferences</p>
                  <p className="text-[#E1E1E1] text-sm">87% Match</p>
                </div>
                <div className="relative h-2 bg-[#4A4A4A] rounded-full overflow-hidden">
                  <div className="absolute inset-y-0 left-0 bg-[#E8C8A9]" style={{ width: '87%' }}></div>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <div className="flex-1 bg-[#4A4A4A] p-3 rounded-lg">
                  <p className="text-[#E1E1E1] text-xs mb-1">Primary Style</p>
                  <p className="text-white font-medium">Modern Minimal</p>
                </div>
                <div className="flex-1 bg-[#4A4A4A] p-3 rounded-lg">
                  <p className="text-[#E1E1E1] text-xs mb-1">Secondary Style</p>
                  <p className="text-white font-medium">Business Casual</p>
                </div>
                <div className="flex-1 bg-[#4A4A4A] p-3 rounded-lg">
                  <p className="text-[#E1E1E1] text-xs mb-1">Accent Style</p>
                  <p className="text-white font-medium">Vintage</p>
                </div>
              </div>
              
              <div>
                <p className="text-[#E1E1E1] text-sm mb-3">Color Preferences</p>
                <div className="flex flex-wrap gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#F8F8F8] ring-2 ring-[#E8C8A9]"></div>
                  <div className="w-8 h-8 rounded-full bg-[#4A4A4A]"></div>
                  <div className="w-8 h-8 rounded-full bg-blue-700"></div>
                  <div className="w-8 h-8 rounded-full bg-emerald-700"></div>
                  <div className="w-8 h-8 rounded-full bg-amber-700"></div>
                  <div className="w-8 h-8 rounded-full bg-rose-700"></div>
                  <div className="w-8 h-8 rounded-full border border-dashed border-[#888888] flex items-center justify-center">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-4 w-4 text-[#888888]" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                  </div>
                </div>
              </div>
              
              <div>
                <p className="text-[#E1E1E1] text-sm mb-3">Recently Liked Items</p>
                <div className="grid grid-cols-4 gap-2">
                  {likedItems.map((item, index) => (
                    <img 
                      key={index}
                      src={item} 
                      alt="Liked item" 
                      className="aspect-square rounded-md object-cover" 
                    />
                  ))}
                </div>
              </div>
              
              <Link href="/style-analysis">
                <a className="block text-center font-medium text-[#E8C8A9] hover:text-white transition-colors">
                  View Full Style Analysis
                </a>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
