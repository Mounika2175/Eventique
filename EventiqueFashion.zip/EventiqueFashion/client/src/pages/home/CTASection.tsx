import { Link } from "wouter";
import { motion } from "framer-motion";

export default function CTASection() {
  return (
    <section className="py-16 md:py-24 bg-[#E8C8A9]">
      <div className="container mx-auto px-4 text-center">
        <motion.h2 
          className="font-[Playfair_Display] text-3xl md:text-5xl font-bold text-[#222222] mb-6"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Ready to Transform Your Style?
        </motion.h2>
        <motion.p 
          className="max-w-2xl mx-auto text-[#4A4A4A] mb-10 text-lg"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          Join EVENTIQUE today and experience the future of fashion with personalized recommendations, virtual try-ons, and premium rentals.
        </motion.p>
        <motion.div 
          className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link href="/register">
              <a className="font-[Montserrat] px-10 py-4 rounded-full bg-[#222222] text-white text-lg font-semibold hover:bg-[#2A2A2A] transition-all">
                Create Free Account
              </a>
            </Link>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link href="/demo">
              <a className="font-[Montserrat] px-10 py-4 rounded-full border-2 border-[#222222] text-[#222222] text-lg font-semibold hover:bg-white hover:bg-opacity-30 transition-all">
                Schedule Demo
              </a>
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
