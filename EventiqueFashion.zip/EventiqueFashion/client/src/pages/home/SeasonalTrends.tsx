import { Link } from "wouter";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

const seasons = [
  {
    name: "Spring",
    description: "Light layers & fresh colors",
    imageUrl: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=873&q=80"
  },
  {
    name: "Summer",
    description: "Breathable fabrics & vibrant tones",
    imageUrl: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80"
  },
  {
    name: "Fall",
    description: "Rich textures & warm hues",
    imageUrl: "https://images.unsplash.com/photo-1550639525-c97d455acf70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80"
  },
  {
    name: "Winter",
    description: "Cozy layers & elegant styles",
    imageUrl: "https://images.unsplash.com/photo-1548624313-0396c75f8e60?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80"
  }
];

export default function SeasonalTrends() {
  const weatherOutfits = [
    "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
    "https://images.unsplash.com/photo-1581044777550-4cfa60707c03?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80"
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1, transition: { duration: 0.6 } }
  };

  return (
    <section className="py-16 md:py-24 bg-[#F8F8F8]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-[Playfair_Display] text-3xl md:text-4xl font-bold text-[#222222] mb-4">
            Seasonal & Weather-Based Recommendations
          </h2>
          <p className="max-w-2xl mx-auto text-[#4A4A4A]">
            Stay stylish in any weather with our real-time recommendations that adapt to your local forecast and seasonal trends.
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.1 }}
        >
          {seasons.map((season, index) => (
            <motion.div 
              key={index} 
              className="relative rounded-2xl overflow-hidden shadow-lg group"
              variants={item}
            >
              <img 
                src={season.imageUrl} 
                alt={`${season.name} Fashion`} 
                className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="font-[Playfair_Display] text-2xl font-semibold text-white mb-2">
                  {season.name}
                </h3>
                <p className="text-[#E1E1E1] mb-4">{season.description}</p>
                <Link href={`/collection/${season.name.toLowerCase()}`}>
                  <a className="inline-block text-sm font-medium text-white hover:text-[#E8C8A9] transition-colors">
                    View Collection
                  </a>
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
        
        <motion.div 
          className="mt-16 bg-white rounded-2xl shadow-lg p-6 md:p-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-8 w-8 text-[#E8C8A9] mr-4" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" 
                  />
                </svg>
                <div>
                  <h3 className="font-[Playfair_Display] text-xl font-semibold text-[#222222]">Today's Weather in New York</h3>
                  <p className="text-[#888888]">68°F, Partly Cloudy</p>
                </div>
              </div>
              <p className="mt-4 text-[#4A4A4A]">Perfect day for light layers with a light jacket or cardigan.</p>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              {weatherOutfits.map((outfit, index) => (
                <div key={index} className="aspect-square rounded-md overflow-hidden">
                  <img 
                    src={outfit} 
                    alt="Weather-appropriate outfit" 
                    className="w-full h-full object-cover" 
                  />
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
