import { useState } from "react";
import { 
  Card, 
  CardContent
} from "@/components/ui/card";
import { 
  Undo, 
  RotateCw, 
  ZoomIn,
  User
} from "lucide-react";

type AvatarCategory = 'tops' | 'bottoms' | 'shoes' | 'accessories';

interface CategoryOption {
  icon: React.ReactNode;
  label: string;
  value: AvatarCategory;
}

const AvatarCreator = () => {
  const [selectedCategory, setSelectedCategory] = useState<AvatarCategory | null>(null);

  const categories: CategoryOption[] = [
    {
      icon: <i className="fas fa-tshirt text-secondary"></i>,
      label: "Tops",
      value: "tops"
    },
    {
      icon: <i className="fas fa-socks text-secondary"></i>,
      label: "Bottoms",
      value: "bottoms"
    },
    {
      icon: <i className="fas fa-shoe-prints text-secondary"></i>,
      label: "Shoes",
      value: "shoes"
    },
    {
      icon: <i className="fas fa-gem text-secondary"></i>,
      label: "Accessories",
      value: "accessories"
    }
  ];

  const handleCategorySelect = (category: AvatarCategory) => {
    setSelectedCategory(category);
  };

  return (
    <div className="lg:w-1/2 avatar-bg rounded-2xl p-8">
      <div className="relative aspect-[3/4] rounded-xl overflow-hidden bg-neutral-800 flex items-center justify-center">
        {/* Avatar placeholder */}
        <div className="text-center p-6">
          <div className="w-24 h-24 mx-auto mb-4 rounded-full border-2 border-dashed border-secondary flex items-center justify-center">
            <User className="h-12 w-12 text-secondary" />
          </div>
          <p className="text-neutral-300 text-lg">Your 3D Avatar</p>
          <p className="text-neutral-400 text-sm mt-2">
            This is where your interactive 3D model will appear
          </p>
        </div>

        {/* Controls */}
        <div className="absolute bottom-4 left-4 right-4 flex justify-center space-x-4">
          <button className="w-10 h-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center hover:bg-opacity-20 transition-colors">
            <Undo className="h-5 w-5 text-white" />
          </button>
          <button className="w-10 h-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center hover:bg-opacity-20 transition-colors">
            <RotateCw className="h-5 w-5 text-white" />
          </button>
          <button className="w-10 h-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center hover:bg-opacity-20 transition-colors">
            <ZoomIn className="h-5 w-5 text-white" />
          </button>
        </div>
      </div>

      {/* Category options */}
      <div className="mt-6 grid grid-cols-4 gap-4">
        {categories.map((category) => (
          <div
            key={category.value}
            className={`bg-white bg-opacity-10 rounded-lg p-2 cursor-pointer hover:bg-opacity-20 transition-colors ${
              selectedCategory === category.value ? "ring-2 ring-secondary" : ""
            }`}
            onClick={() => handleCategorySelect(category.value)}
          >
            <div className="aspect-square rounded-md bg-neutral-800 flex items-center justify-center">
              {category.icon}
            </div>
            <p className="text-xs text-center mt-1 text-white">{category.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AvatarCreator;
