import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  ChevronLeft, 
  ChevronRight 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface CalendarDay {
  date: number;
  isCurrentMonth: boolean;
  hasEvent: boolean;
  eventType?: 'meeting' | 'dinner' | 'other';
}

interface Event {
  id: number;
  title: string;
  date: string;
  time: string;
  type: 'meeting' | 'dinner' | 'other';
  formalityLevel: 'Formal' | 'Smart Casual' | 'Casual';
  outfitRecommendation: {
    image: string;
    name: string;
    description: string;
  };
}

const CalendarIntegration = () => {
  const [currentMonth, setCurrentMonth] = useState("October 2023");
  
  // Generate calendar days
  const generateDays = (): CalendarDay[] => {
    const days: CalendarDay[] = [];
    // In a real application, this would be dynamically generated
    for (let i = 1; i <= 20; i++) {
      days.push({
        date: i,
        isCurrentMonth: true,
        hasEvent: i === 11 || i === 13 || i === 18,
        eventType: i === 11 ? 'meeting' : i === 13 ? 'dinner' : undefined
      });
    }
    return days;
  };

  const calendarDays = generateDays();
  
  const events: Event[] = [
    {
      id: 1,
      title: "Business Meeting",
      date: "Oct 11",
      time: "9:00 AM - 10:30 AM",
      type: "meeting",
      formalityLevel: "Formal",
      outfitRecommendation: {
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
        name: "Navy suit with white shirt",
        description: "Professional business attire"
      }
    },
    {
      id: 2,
      title: "Dinner Party",
      date: "Oct 13",
      time: "7:00 PM - 10:00 PM",
      type: "dinner",
      formalityLevel: "Smart Casual",
      outfitRecommendation: {
        image: "https://images.unsplash.com/photo-1549062572-544a64fb0c56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
        name: "Casual blazer with chinos",
        description: "Elegant yet comfortable"
      }
    }
  ];

  const handlePrevMonth = () => {
    // In a real app, this would change the month
    setCurrentMonth("September 2023");
  };

  const handleNextMonth = () => {
    // In a real app, this would change the month
    setCurrentMonth("November 2023");
  };

  const getEventBadgeColor = (type?: 'meeting' | 'dinner' | 'other') => {
    switch (type) {
      case 'meeting':
        return 'bg-accent text-white';
      case 'dinner':
        return 'bg-secondary text-primary';
      default:
        return 'bg-neutral-300';
    }
  };

  return (
    <div className="lg:w-1/2 bg-neutral-100 rounded-2xl p-6 shadow-lg">
      <Card className="bg-white rounded-xl shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="font-playfair text-xl font-semibold text-primary">
            Your Events
          </CardTitle>
          <div className="flex space-x-2">
            <button 
              className="w-8 h-8 rounded-full bg-neutral-100 flex items-center justify-center hover:bg-neutral-200 transition-colors"
              onClick={handlePrevMonth}
            >
              <ChevronLeft className="h-4 w-4 text-neutral-500" />
            </button>
            <button 
              className="w-8 h-8 rounded-full bg-neutral-100 flex items-center justify-center hover:bg-neutral-200 transition-colors"
              onClick={handleNextMonth}
            >
              <ChevronRight className="h-4 w-4 text-neutral-500" />
            </button>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="mb-6">
            <div className="text-center mb-4">
              <h4 className="font-medium text-neutral-700">{currentMonth}</h4>
            </div>
            
            <div className="grid grid-cols-7 mb-2">
              {["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"].map((day) => (
                <div key={day} className="text-neutral-400 text-xs text-center">
                  {day}
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map((day, index) => (
                <div
                  key={index}
                  className={`calendar-day text-sm aspect-square flex items-center justify-center rounded-full ${
                    day.hasEvent 
                      ? getEventBadgeColor(day.eventType)
                      : 'hover:bg-secondary hover:text-primary'
                  }`}
                >
                  {day.date}
                </div>
              ))}
            </div>
          </div>
          
          <div className="space-y-4">
            {events.map((event) => (
              <div 
                key={event.id}
                className={`border-l-4 ${
                  event.type === 'meeting' 
                    ? 'border-accent bg-accent bg-opacity-5' 
                    : 'border-secondary bg-secondary bg-opacity-5'
                } p-3 rounded-r-lg`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h5 className="font-medium text-primary">{event.title}</h5>
                    <p className="text-sm text-neutral-500">{event.date}, {event.time}</p>
                  </div>
                  <Badge 
                    className={`text-xs px-2 py-1 rounded-full ${
                      event.type === 'meeting' 
                        ? 'bg-accent text-white' 
                        : 'bg-secondary text-primary'
                    }`}
                  >
                    {event.formalityLevel}
                  </Badge>
                </div>
                <div className="mt-3 flex items-center">
                  <img 
                    src={event.outfitRecommendation.image} 
                    alt="Outfit suggestion" 
                    className="w-12 h-16 object-cover rounded-md" 
                  />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-primary">Recommended Outfit</p>
                    <p className="text-xs text-neutral-500">{event.outfitRecommendation.name}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CalendarIntegration;
