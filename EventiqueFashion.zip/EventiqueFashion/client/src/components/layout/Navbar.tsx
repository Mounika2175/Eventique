import { useLocation, Link } from "wouter";
import { useState } from "react";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Menu, 
  User, 
  Settings, 
  LogOut, 
  Heart, 
  Calendar, 
  ShoppingBag 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";

export default function Navbar() {
  const [location, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  const navItems = [
    { label: "Home", path: "/" },
    { label: "About Us", path: "/about" },
    { label: "Features", path: "/features" },
    { label: "Fashion Rentals", path: "/rentals" },
    { label: "Contact", path: "/contact" }
  ];

  const closeSheet = () => {
    setOpen(false);
  };

  const handleLogout = () => {
    logout();
  };

  // Get user's initials for avatar fallback
  const getInitials = () => {
    if (!user) return "U";
    
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`;
    }
    
    return user.username.slice(0, 2).toUpperCase();
  };

  return (
    <nav className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <button 
              className="font-[Playfair_Display] text-2xl font-bold text-[#222222] tracking-wide bg-transparent border-none cursor-pointer"
              onClick={() => {
                if (isAuthenticated) {
                  setLocation('/dashboard');
                } else {
                  setLocation('/');
                }
              }}
            >
              EVENTIQUE
            </button>
          </div>
          
          <div className="hidden md:flex space-x-8 items-center">
            {navItems.map((item) => {
              // If user is authenticated and trying to go to home, redirect to dashboard
              const handleNavClick = (e: React.MouseEvent) => {
                e.preventDefault();
                if (isAuthenticated && item.path === '/') {
                  setLocation('/dashboard');
                } else {
                  setLocation(item.path);
                }
              };
              
              return (
                <button
                  key={item.path}
                  onClick={handleNavClick}
                  className={`relative font-medium bg-transparent border-none hover:text-[#222222] after:content-[''] after:absolute after:bottom-[-5px] after:left-0 after:w-0 after:h-0.5 after:bg-[#E8C8A9] after:transition-all after:duration-300 hover:after:w-full ${location === item.path ? 'text-[#222222] after:w-full' : 'text-[#888888]'}`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="hidden md:flex items-center space-x-4">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                      <Avatar className="h-10 w-10 border-2 border-[#E8C8A9]">
                        <AvatarImage src={`https://ui-avatars.com/api/?name=${user?.username}&background=E8C8A9&color=222222`} alt={user?.username} />
                        <AvatarFallback className="bg-[#E8C8A9] text-[#222222]">{getInitials()}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel>
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{user?.username}</p>
                        <p className="text-xs leading-none text-gray-500">{user?.email}</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation('/profile')}>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation('/avatar')}>
                      <User className="mr-2 h-4 w-4" />
                      <span>My Avatar</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation('/favorites')}>
                      <Heart className="mr-2 h-4 w-4" />
                      <span>Favorites</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation('/calendar')}>
                      <Calendar className="mr-2 h-4 w-4" />
                      <span>My Events</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation('/rentals')}>
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      <span>My Rentals</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation('/settings')}>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="cursor-pointer" onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <>
                <button
                  className="hidden md:inline-block font-[Montserrat] px-6 py-2 rounded-full text-white bg-[#222222] hover:bg-[#2A2A2A] transition-colors"
                  onClick={() => setLocation('/signin')}
                >
                  Sign In
                </button>
                <button
                  className="hidden md:inline-block font-[Montserrat] px-6 py-2 rounded-full text-[#222222] border border-[#222222] hover:bg-[#222222] hover:text-white transition-colors"
                  onClick={() => setLocation('/register')}
                >
                  Register
                </button>
              </>
            )}
            
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6 text-[#222222]" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[80%] sm:w-[350px]">
                {isAuthenticated && (
                  <div className="flex items-center space-x-3 mt-6 mb-6">
                    <Avatar className="h-10 w-10 border-2 border-[#E8C8A9]">
                      <AvatarImage src={`https://ui-avatars.com/api/?name=${user?.username}&background=E8C8A9&color=222222`} alt={user?.username} />
                      <AvatarFallback className="bg-[#E8C8A9] text-[#222222]">{getInitials()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{user?.username}</p>
                      <p className="text-xs text-gray-500">{user?.email}</p>
                    </div>
                  </div>
                )}
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => {
                    // If user is authenticated and trying to go to home, redirect to dashboard
                    const handleItemClick = () => {
                      if (isAuthenticated && item.path === '/') {
                        setLocation('/dashboard');
                      } else {
                        setLocation(item.path);
                      }
                      closeSheet();
                    };
                    
                    return (
                      <button
                        key={item.path}
                        className={`px-4 py-2 rounded-md text-left w-full ${location === item.path ? 'bg-[#E8C8A9] text-[#222222] font-medium' : 'text-[#4A4A4A] hover:bg-[#F8F8F8]'}`}
                        onClick={handleItemClick}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                  
                  {isAuthenticated ? (
                    <>
                      <div className="border-t border-gray-200 pt-4 mt-4">
                        <h3 className="px-4 text-sm font-semibold text-gray-500 mb-2">MY ACCOUNT</h3>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            setLocation('/profile');
                            closeSheet();
                          }}
                        >
                          <User className="mr-2 h-4 w-4" />
                          <span>Profile</span>
                        </button>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            setLocation('/avatar');
                            closeSheet();
                          }}
                        >
                          <User className="mr-2 h-4 w-4" />
                          <span>My Avatar</span>
                        </button>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            setLocation('/favorites');
                            closeSheet();
                          }}
                        >
                          <Heart className="mr-2 h-4 w-4" />
                          <span>Favorites</span>
                        </button>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            setLocation('/calendar');
                            closeSheet();
                          }}
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>My Events</span>
                        </button>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            setLocation('/rentals');
                            closeSheet();
                          }}
                        >
                          <ShoppingBag className="mr-2 h-4 w-4" />
                          <span>My Rentals</span>
                        </button>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            setLocation('/settings');
                            closeSheet();
                          }}
                        >
                          <Settings className="mr-2 h-4 w-4" />
                          <span>Settings</span>
                        </button>
                        <button 
                          className="flex items-center w-full text-left px-4 py-2 rounded-md text-[#D64045] hover:bg-[#F8F8F8]"
                          onClick={() => {
                            handleLogout();
                            closeSheet();
                          }}
                        >
                          <LogOut className="mr-2 h-4 w-4" />
                          <span>Log out</span>
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="border-t border-gray-200 pt-4 mt-4">
                      <button
                        className="block w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                        onClick={() => {
                          setLocation('/signin');
                          closeSheet();
                        }}
                      >
                        Sign In
                      </button>
                      <button
                        className="block w-full text-left px-4 py-2 rounded-md text-[#4A4A4A] hover:bg-[#F8F8F8]"
                        onClick={() => {
                          setLocation('/register');
                          closeSheet();
                        }}
                      >
                        Register
                      </button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
