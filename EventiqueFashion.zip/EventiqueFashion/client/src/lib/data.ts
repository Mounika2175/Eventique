// Fashion Categories
export const fashionCategories = [
  { id: 'tops', name: 'Tops', icon: 'tshirt' },
  { id: 'bottoms', name: 'Bottoms', icon: 'socks' },
  { id: 'dresses', name: 'Dresses', icon: 'female' },
  { id: 'outerwear', name: 'Outerwear', icon: 'user-tie' },
  { id: 'shoes', name: 'Shoes', icon: 'shoe-prints' },
  { id: 'accessories', name: 'Accessories', icon: 'gem' }
];

// Event Types
export const eventTypes = [
  { id: 'formal', name: 'Formal', color: '#D64045' },
  { id: 'business', name: 'Business', color: '#4A4A4A' },
  { id: 'casual', name: 'Casual', color: '#2E8B57' },
  { id: 'party', name: 'Party', color: '#9370DB' },
  { id: 'wedding', name: 'Wedding', color: '#E8C8A9' },
  { id: 'outdoor', name: 'Outdoor', color: '#6495ED' }
];

// Seasons
export const seasons = [
  { 
    id: 'spring', 
    name: 'Spring', 
    description: 'Light layers & fresh colors',
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=873&q=80'
  },
  { 
    id: 'summer', 
    name: 'Summer', 
    description: 'Breathable fabrics & vibrant tones',
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80'
  },
  { 
    id: 'fall', 
    name: 'Fall', 
    description: 'Rich textures & warm hues',
    image: 'https://images.unsplash.com/photo-1550639525-c97d455acf70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80'
  },
  { 
    id: 'winter', 
    name: 'Winter', 
    description: 'Cozy layers & elegant styles',
    image: 'https://images.unsplash.com/photo-1548624313-0396c75f8e60?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80'
  }
];

// Weather-Based Outfit Items
export const weatherOutfits = [
  {
    condition: 'sunny',
    items: [
      'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80',
      'https://images.unsplash.com/photo-1581044777550-4cfa60707c03?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
    ]
  },
  {
    condition: 'rainy',
    items: [
      'https://images.unsplash.com/photo-1519736902035-a6a5a311d751?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80',
      'https://images.unsplash.com/photo-1545594861-3bbef5cm4d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80',
      'https://images.unsplash.com/photo-1562157873-818bc0726f68?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
    ]
  },
  {
    condition: 'cold',
    items: [
      'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80',
      'https://images.unsplash.com/photo-1580657018950-c7f7d6a6d990?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80',
      'https://images.unsplash.com/photo-1599719361194-e2de16d42d4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
    ]
  }
];

// Color Preferences for Styling
export const colorPreferences = [
  { id: 'neutral', color: '#F8F8F8', name: 'Neutral' },
  { id: 'black', color: '#222222', name: 'Black' },
  { id: 'blue', color: '#3B82F6', name: 'Blue' },
  { id: 'green', color: '#10B981', name: 'Green' },
  { id: 'yellow', color: '#F59E0B', name: 'Yellow' },
  { id: 'red', color: '#EF4444', name: 'Red' },
  { id: 'purple', color: '#8B5CF6', name: 'Purple' }
];

// Style Profiles
export const styleProfiles = [
  { id: 'minimal', name: 'Modern Minimal', description: 'Clean lines, neutral colors, and simple silhouettes' },
  { id: 'business', name: 'Business Casual', description: 'Professional yet approachable attire for the workplace' },
  { id: 'vintage', name: 'Vintage', description: 'Retro aesthetics with a modern twist' },
  { id: 'bohemian', name: 'Bohemian', description: 'Free-spirited, layered looks with artistic flair' },
  { id: 'athleisure', name: 'Athleisure', description: 'Sporty, comfortable pieces with street style appeal' },
  { id: 'glamorous', name: 'Glamorous', description: 'Bold, statement pieces with luxurious details' }
];

// Sample Calendar Events (for demo purposes)
export const calendarEvents = [
  {
    id: 1,
    title: 'Business Meeting',
    date: '2023-10-11T09:00:00',
    endDate: '2023-10-11T10:30:00',
    eventType: 'formal',
    outfitSuggestion: {
      name: 'Navy suit with white shirt',
      imageUrl: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 2,
    title: 'Dinner Party',
    date: '2023-10-13T19:00:00',
    endDate: '2023-10-13T22:00:00',
    eventType: 'casual',
    outfitSuggestion: {
      name: 'Casual blazer with chinos',
      imageUrl: 'https://images.unsplash.com/photo-1549062572-544a64fb0c56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 3,
    title: 'Charity Gala',
    date: '2023-10-18T18:00:00',
    endDate: '2023-10-18T23:00:00',
    eventType: 'formal',
    outfitSuggestion: {
      name: 'Evening gown with accessories',
      imageUrl: 'https://images.unsplash.com/photo-1525450824786-227cbef70703?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=435&q=80'
    }
  }
];
